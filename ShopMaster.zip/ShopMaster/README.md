# ShopMaster

App de compras iOS desenvolvido em Swift seguindo o padrão **MVVM** com navegação por `TabView` e `NavigationStack`.

## Estrutura do Projeto

```
ShopMaster/
├── Models/
│   ├── Product.swift       # Entidade produto (id, nome, preço, categoria)
│   └── CartItem.swift      # Item do carrinho (produto + quantidade)
├── ViewModels/
│   ├── CartViewModel.swift        # Lógica do carrinho (add, remove, total)
│   └── ProductListViewModel.swift # Catálogo e filtro por categoria
└── Views/
    ├── ContentView.swift       # TabView raiz (Loja / Carrinho)
    ├── StoreView.swift         # Seções por categoria + grade de produtos
    ├── ProductCardView.swift   # Card reutilizável do produto
    ├── ProductDetailView.swift # Detalhe do produto + botão adicionar
    └── CartView.swift          # Lista do carrinho com subtotais e total
```

## Arquitetura MVVM

| Camada | Responsabilidade |
|--------|-----------------|
| **Model** | Dados puros (`Product`, `CartItem`) sem lógica de UI |
| **ViewModel** | `@Published` + lógica de negócio; `ObservableObject` injetado via `@EnvironmentObject` |
| **View** | SwiftUI declarativo; apenas renderização e interação do usuário |

## Funcionalidades

- **3 seções de produtos**: Eletrônicos, Roupas e Alimentação
- **Navegação**: `TabView` (Loja ↔ Carrinho) + `NavigationStack` (lista → detalhe)
- **Carrinho**: adicionar, aumentar/diminuir quantidade, remover (swipe ou stepper)
- **Badge** no ícone do carrinho com total de itens
- **Total** calculado em tempo real com formatação em BRL

## Como rodar

1. Abra `ShopMaster.xcodeproj` no Xcode 15+
2. Selecione um simulador iPhone (iOS 17+)
3. `⌘R` para rodar

## Requisitos

- Xcode 15+
- iOS 17+
- Swift 5.9+
