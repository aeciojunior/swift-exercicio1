import Foundation

final class ProductListViewModel: ObservableObject {
    @Published private(set) var products: [Product] = []
    @Published var selectedCategory: Product.Category = .electronics

    var filteredProducts: [Product] {
        products.filter { $0.category == selectedCategory }
    }

    init() {
        loadProducts()
    }

    private func loadProducts() {
        products = [
            // Eletrônicos
            Product(id: UUID(), name: "iPhone 15",      description: "Smartphone Apple 128GB",        price: 5999.99, imageName: "iphone",   category: .electronics),
            Product(id: UUID(), name: "AirPods Pro",    description: "Fone com cancelamento de ruído", price: 1799.99, imageName: "airpods",  category: .electronics),
            Product(id: UUID(), name: "MacBook Air",    description: "Notebook Apple M2 8GB",          price: 9499.99, imageName: "macbook",  category: .electronics),
            Product(id: UUID(), name: "iPad Mini",      description: "Tablet Apple 64GB Wi-Fi",        price: 4299.99, imageName: "ipad",     category: .electronics),
            // Roupas
            Product(id: UUID(), name: "Camiseta Básica", description: "100% algodão, várias cores",   price: 59.90,   imageName: "tshirt",   category: .clothing),
            Product(id: UUID(), name: "Calça Jeans",    description: "Slim fit, lavagem escura",       price: 149.90,  imageName: "jeans",    category: .clothing),
            Product(id: UUID(), name: "Tênis Running",  description: "Solado amortecedor",             price: 299.90,  imageName: "sneaker",  category: .clothing),
            Product(id: UUID(), name: "Jaqueta Bomber", description: "Impermeável, zíper YKK",         price: 249.90,  imageName: "jacket",   category: .clothing),
            // Alimentação
            Product(id: UUID(), name: "Café Especial",  description: "Grão arábica torrado",           price: 39.90,   imageName: "coffee",   category: .food),
            Product(id: UUID(), name: "Kit Churrasco",  description: "Carvão + temperos premium",      price: 89.90,   imageName: "bbq",      category: .food),
            Product(id: UUID(), name: "Whey Protein",   description: "1kg sabor chocolate",            price: 129.90,  imageName: "whey",     category: .food),
            Product(id: UUID(), name: "Azeite Extra",   description: "500ml origem portuguesa",        price: 49.90,   imageName: "olive",    category: .food),
        ]
    }
}
