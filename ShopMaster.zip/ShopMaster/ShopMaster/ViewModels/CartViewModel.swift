import Foundation
import Combine

final class CartViewModel: ObservableObject {
    @Published private(set) var items: [CartItem] = []

    var total: Double {
        items.reduce(0) { $0 + $1.subtotal }
    }

    var totalFormatted: String {
        total.formatted(.currency(code: "BRL"))
    }

    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }

    func add(_ product: Product) {
        if let index = items.firstIndex(where: { $0.product == product }) {
            items[index].quantity += 1
        } else {
            items.append(CartItem(product: product))
        }
    }

    func remove(_ item: CartItem) {
        items.removeAll { $0.id == item.id }
    }

    func decrease(_ item: CartItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        if items[index].quantity > 1 {
            items[index].quantity -= 1
        } else {
            items.remove(at: index)
        }
    }
}
