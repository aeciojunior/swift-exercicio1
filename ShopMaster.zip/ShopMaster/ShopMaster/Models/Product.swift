import Foundation

struct Product: Identifiable, Equatable {
    let id: UUID
    let name: String
    let description: String
    let price: Double
    let imageName: String
    let category: Category

    enum Category: String, CaseIterable {
        case electronics = "Eletrônicos"
        case clothing    = "Roupas"
        case food        = "Alimentação"
    }

    static func == (lhs: Product, rhs: Product) -> Bool {
        lhs.id == rhs.id
    }
}
