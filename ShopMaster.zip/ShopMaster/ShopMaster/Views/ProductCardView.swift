import SwiftUI

struct ProductCardView: View {
    let product: Product
    @EnvironmentObject private var cart: CartViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Product icon placeholder
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemGray6))
                .frame(height: 120)
                .overlay(
                    Image(systemName: iconFor(product.category))
                        .font(.system(size: 40))
                        .foregroundStyle(.secondary)
                )

            VStack(alignment: .leading, spacing: 4) {
                Text(product.name)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .lineLimit(1)

                Text(product.price.formatted(.currency(code: "BRL")))
                    .font(.footnote)
                    .foregroundStyle(.green)
                    .fontWeight(.bold)
            }
            .padding(.horizontal, 4)

            Button {
                cart.add(product)
            } label: {
                Label("Adicionar", systemImage: "cart.badge.plus")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(Color.accentColor)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            }
        }
        .padding(10)
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.07), radius: 4, y: 2)
    }

    private func iconFor(_ category: Product.Category) -> String {
        switch category {
        case .electronics: return "desktopcomputer"
        case .clothing:    return "tshirt"
        case .food:        return "fork.knife"
        }
    }
}
