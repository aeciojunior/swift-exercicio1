import SwiftUI

struct CartView: View {
    @EnvironmentObject private var cart: CartViewModel

    var body: some View {
        NavigationStack {
            Group {
                if cart.items.isEmpty {
                    emptyState
                } else {
                    cartList
                }
            }
            .navigationTitle("Carrinho")
        }
    }

    // MARK: - Subviews

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "cart")
                .font(.system(size: 60))
                .foregroundStyle(.secondary)
            Text("Seu carrinho está vazio")
                .font(.headline)
            Text("Adicione produtos na aba Loja")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var cartList: some View {
        VStack(spacing: 0) {
            List {
                ForEach(cart.items) { item in
                    CartItemRow(item: item)
                }
                .onDelete { indexSet in
                    indexSet.map { cart.items[$0] }.forEach { cart.remove($0) }
                }
            }
            .listStyle(.plain)

            // Footer total
            VStack(spacing: 12) {
                Divider()
                HStack {
                    Text("Total")
                        .font(.headline)
                    Spacer()
                    Text(cart.totalFormatted)
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundStyle(.green)
                }
                .padding(.horizontal)

                Button {
                    // Checkout action (placeholder)
                } label: {
                    Text("Finalizar Compra")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.accentColor)
                        .foregroundStyle(.white)
                        .fontWeight(.semibold)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding(.horizontal)
                .padding(.bottom, 8)
            }
            .background(.background)
        }
    }
}

// MARK: - CartItemRow

struct CartItemRow: View {
    let item: CartItem
    @EnvironmentObject private var cart: CartViewModel

    var body: some View {
        HStack(spacing: 12) {
            // Icon
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(.systemGray6))
                .frame(width: 56, height: 56)
                .overlay(
                    Image(systemName: "shippingbox")
                        .foregroundStyle(.secondary)
                )

            VStack(alignment: .leading, spacing: 4) {
                Text(item.product.name)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Text(item.subtotal.formatted(.currency(code: "BRL")))
                    .font(.footnote)
                    .foregroundStyle(.green)
            }

            Spacer()

            // Quantity stepper
            HStack(spacing: 4) {
                Button {
                    cart.decrease(item)
                } label: {
                    Image(systemName: "minus.circle.fill")
                        .foregroundStyle(.secondary)
                }

                Text("\(item.quantity)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .frame(minWidth: 24)

                Button {
                    cart.add(item.product)
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .foregroundStyle(.accentColor)
                }
            }
            .font(.title3)
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    CartView().environmentObject(CartViewModel())
}
