import SwiftUI

struct ContentView: View {
    @StateObject private var cart = CartViewModel()

    var body: some View {
        TabView {
            StoreView()
                .tabItem {
                    Label("Loja", systemImage: "storefront")
                }

            CartView()
                .tabItem {
                    Label("Carrinho", systemImage: "cart")
                }
                .badge(cart.itemCount > 0 ? "\(cart.itemCount)" : nil)
        }
        .environmentObject(cart)
    }
}

#Preview {
    ContentView()
}
