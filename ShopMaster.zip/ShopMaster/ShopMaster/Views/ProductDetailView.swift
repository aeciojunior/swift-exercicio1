import SwiftUI

struct ProductDetailView: View {
    let product: Product
    @EnvironmentObject private var cart: CartViewModel
    @State private var added = false

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // Hero Image Placeholder
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color(.systemGray6))
                    .frame(maxWidth: .infinity)
                    .frame(height: 240)
                    .overlay(
                        Image(systemName: iconFor(product.category))
                            .font(.system(size: 80))
                            .foregroundStyle(.secondary)
                    )
                    .padding(.horizontal)

                VStack(alignment: .leading, spacing: 12) {
                    // Header
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(product.name)
                                .font(.title2)
                                .fontWeight(.bold)
                            Text(product.category.rawValue)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(product.price.formatted(.currency(code: "BRL")))
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundStyle(.green)
                    }

                    Divider()

                    Text("Descrição")
                        .font(.headline)
                    Text(product.description)
                        .font(.body)
                        .foregroundStyle(.secondary)
                }
                .padding(.horizontal)

                // Add to Cart Button
                Button {
                    cart.add(product)
                    added = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        added = false
                    }
                } label: {
                    Label(
                        added ? "Adicionado!" : "Adicionar ao Carrinho",
                        systemImage: added ? "checkmark" : "cart.badge.plus"
                    )
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(added ? Color.green : Color.accentColor)
                    .foregroundStyle(.white)
                    .fontWeight(.semibold)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .animation(.easeInOut(duration: 0.3), value: added)
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        .navigationTitle(product.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func iconFor(_ category: Product.Category) -> String {
        switch category {
        case .electronics: return "desktopcomputer"
        case .clothing:    return "tshirt"
        case .food:        return "fork.knife"
        }
    }
}
