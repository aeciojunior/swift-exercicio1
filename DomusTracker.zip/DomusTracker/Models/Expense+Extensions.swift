//
//  Expense+Extensions.swift
//  DomusTracker
//
//  Propósito: Estende a entidade Expense do Core Data com propriedades computadas e métodos auxiliares
//  Este arquivo adiciona métodos de conveniência para facilitar o trabalho com objetos Expense
//

import Foundation
import CoreData

// MARK: - Extensões de Expense

/// Extensão para adicionar propriedades computadas e métodos auxiliares à entidade Expense
/// A própria classe Expense é gerada automaticamente pelo Core Data a partir do arquivo .xcdatamodeld
/// Nós a estendemos aqui para adicionar funcionalidade personalizada
extension Expense {
    
    // MARK: - Propriedades Computadas
    
    /// Retorna a categoria como um enum ExpenseCategory
    /// Isso fornece acesso type-safe à categoria em vez de usar strings
    var categoryEnum: ExpenseCategory? {
        guard let categoryString = self.category else { return nil }
        return ExpenseCategory.from(string: categoryString)
    }
    
    /// Retorna o mês como um enum ExpenseMonth
    /// Isso fornece acesso type-safe ao mês em vez de usar strings
    var monthEnum: ExpenseMonth? {
        guard let monthString = self.month else { return nil }
        return ExpenseMonth.from(string: monthString)
    }
    
    /// Retorna o valor formatado como moeda Real Brasileiro (BRL)
    /// Exemplo: "R$ 150,00"
    var formattedAmount: String {
        // Obtém o valor como um Double
        // NSDecimalNumber é usado pelo Core Data para valores decimais precisos
        let amountValue = self.amount?.doubleValue ?? 0.0
        
        // Cria um formatador de números para moeda brasileira
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.currencyCode = "BRL"
        
        // Formata e retorna o valor
        return formatter.string(from: NSNumber(value: amountValue)) ?? "R$ 0,00"
    }
    
    /// Retorna o valor como um valor Double
    /// Propriedade de conveniência para evitar lidar com NSDecimalNumber
    var amountValue: Double {
        return self.amount?.doubleValue ?? 0.0
    }
    
    /// Retorna a data de criação formatada como uma string legível
    /// Exemplo: "20 de maio de 2026"
    var formattedCreatedDate: String {
        guard let date = self.createdAt else { return "" }
        
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        
        return formatter.string(from: date)
    }
    
    /// Retorna a data e hora de criação formatadas como uma string legível
    /// Exemplo: "20/05/2026 às 14:30"
    var formattedCreatedDateTime: String {
        guard let date = self.createdAt else { return "" }
        
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateFormat = "dd/MM/yyyy 'às' HH:mm"
        
        return formatter.string(from: date)
    }
    
    /// Retorna a data da última atualização formatada como uma string legível
    /// Exemplo: "20/05/2026 às 14:30"
    var formattedUpdatedDateTime: String {
        guard let date = self.updatedAt else { return "" }
        
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateFormat = "dd/MM/yyyy 'às' HH:mm"
        
        return formatter.string(from: date)
    }
    
    /// Retorna uma descrição curta para exibição
    /// Se não existir descrição, retorna uma mensagem padrão
    var displayDescription: String {
        if let desc = self.descriptionText, !desc.isEmpty {
            return desc
        }
        return "Sem descrição"
    }
    
    /// Retorna true se a despesa tiver uma descrição
    var hasDescription: Bool {
        guard let desc = self.descriptionText else { return false }
        return !desc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    // MARK: - Inicializadores de Conveniência
    
    /// Cria uma nova Expense com todos os campos obrigatórios
    /// Este é um método de conveniência para facilitar a criação de despesas
    ///
    /// - Parameters:
    ///   - context: O contexto de objeto gerenciado para criar a despesa
    ///   - category: A categoria da despesa
    ///   - month: O mês da despesa
    ///   - amount: O valor da despesa em BRL
    ///   - description: Descrição opcional da despesa
    /// - Returns: Um novo objeto Expense
    static func create(
        in context: NSManagedObjectContext,
        category: ExpenseCategory,
        month: ExpenseMonth,
        amount: Double,
        description: String? = nil
    ) -> Expense {
        let expense = Expense(context: context)
        expense.id = UUID()
        expense.category = category.rawValue
        expense.month = month.rawValue
        expense.amount = NSDecimalNumber(value: amount)
        expense.descriptionText = description
        expense.createdAt = Date()
        expense.updatedAt = Date()
        return expense
    }
    
    // MARK: - Métodos de Atualização
    
    /// Atualiza a despesa com novos valores
    /// Atualiza automaticamente o timestamp updatedAt
    ///
    /// - Parameters:
    ///   - category: A nova categoria
    ///   - month: O novo mês
    ///   - amount: O novo valor
    ///   - description: A nova descrição
    func update(
        category: ExpenseCategory,
        month: ExpenseMonth,
        amount: Double,
        description: String?
    ) {
        self.category = category.rawValue
        self.month = month.rawValue
        self.amount = NSDecimalNumber(value: amount)
        self.descriptionText = description
        self.updatedAt = Date()
    }
    
    // MARK: - Métodos de Validação
    
    /// Valida os dados da despesa
    /// Lança um erro se os dados forem inválidos
    ///
    /// - Throws: ExpenseValidationError se a validação falhar
    func validate() throws {
        // Valida a categoria
        guard let categoryString = self.category,
              ExpenseCategory.from(string: categoryString) != nil else {
            throw ExpenseValidationError.invalidCategory
        }
        
        // Valida o mês
        guard let monthString = self.month,
              ExpenseMonth.from(string: monthString) != nil else {
            throw ExpenseValidationError.invalidMonth
        }
        
        // Valida o valor
        guard let amount = self.amount,
              amount.doubleValue >= 0 else {
            throw ExpenseValidationError.invalidAmount
        }
        
        // Valida o comprimento da descrição se presente
        if let description = self.descriptionText,
           description.count > 200 {
            throw ExpenseValidationError.descriptionTooLong
        }
    }
    
    /// Verifica se a despesa é válida sem lançar exceção
    /// - Returns: True se a despesa for válida, false caso contrário
    var isValid: Bool {
        do {
            try validate()
            return true
        } catch {
            return false
        }
    }
}

// MARK: - Erros de Validação

/// Erros que podem ocorrer ao validar uma Expense
enum ExpenseValidationError: LocalizedError {
    case invalidCategory
    case invalidMonth
    case invalidAmount
    case descriptionTooLong
    
    var errorDescription: String? {
        switch self {
        case .invalidCategory:
            return "Categoria inválida. Por favor, selecione uma categoria válida."
        case .invalidMonth:
            return "Mês inválido. Por favor, selecione um mês válido."
        case .invalidAmount:
            return "Valor inválido. O valor deve ser maior ou igual a zero."
        case .descriptionTooLong:
            return "Descrição muito longa. Máximo de 200 caracteres."
        }
    }
}

// MARK: - Auxiliares de Fetch Request

extension Expense {
    
    /// Cria uma fetch request para todas as despesas
    /// - Returns: Uma fetch request configurada
    static func fetchRequest() -> NSFetchRequest<Expense> {
        return NSFetchRequest<Expense>(entityName: "Expense")
    }
    
    /// Cria uma fetch request para despesas em um mês específico
    /// - Parameter month: O mês para filtrar
    /// - Returns: Uma fetch request configurada
    static func fetchRequest(for month: ExpenseMonth) -> NSFetchRequest<Expense> {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "month == %@", month.rawValue)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)]
        return request
    }
    
    /// Cria uma fetch request para despesas em uma categoria específica
    /// - Parameter category: A categoria para filtrar
    /// - Returns: Uma fetch request configurada
    static func fetchRequest(for category: ExpenseCategory) -> NSFetchRequest<Expense> {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "category == %@", category.rawValue)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)]
        return request
    }
    
    /// Cria uma fetch request para despesas em um mês e categoria específicos
    /// - Parameters:
    ///   - month: O mês para filtrar
    ///   - category: A categoria para filtrar
    /// - Returns: Uma fetch request configurada
    static func fetchRequest(for month: ExpenseMonth, category: ExpenseCategory) -> NSFetchRequest<Expense> {
        let request = fetchRequest()
        request.predicate = NSPredicate(
            format: "month == %@ AND category == %@",
            month.rawValue,
            category.rawValue
        )
        request.sortDescriptors = [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)]
        return request
    }
}

/*
 GUIA PARA INICIANTES SOBRE O USO DESTAS EXTENSÕES:
 
 1. Criando uma nova despesa:
    let expense = Expense.create(
        in: viewContext,
        category: .energia,
        month: .janeiro,
        amount: 150.00,
        description: "Conta de luz"
    )
    try? viewContext.save()
 
 2. Atualizando uma despesa:
    expense.update(
        category: .internet,
        month: .fevereiro,
        amount: 200.00,
        description: "Nova descrição"
    )
    try? viewContext.save()
 
 3. Exibindo valores formatados:
    Text(expense.formattedAmount)           // "R$ 150,00"
    Text(expense.formattedCreatedDate)      // "20 de maio de 2026"
 
 4. Usando enums type-safe:
    if let category = expense.categoryEnum {
        Image(systemName: category.icon)
            .foregroundColor(category.color)
    }
 
 5. Validando uma despesa:
    do {
        try expense.validate()
        // Despesa é válida
    } catch {
        // Mostrar erro ao usuário
        print(error.localizedDescription)
    }
 
 6. Buscando despesas com filtros:
    let request = Expense.fetchRequest(for: .janeiro)
    let januaryExpenses = try? viewContext.fetch(request)
 
 POR QUE USAR EXTENSÕES?
 - Mantém o modelo do Core Data limpo (código gerado automaticamente)
 - Adiciona funcionalidade personalizada sem modificar o código gerado
 - Torna o código mais legível e manutenível
 - Fornece acesso type-safe a propriedades baseadas em strings
 - Centraliza a lógica de formatação
 */

// Feito com Bob
