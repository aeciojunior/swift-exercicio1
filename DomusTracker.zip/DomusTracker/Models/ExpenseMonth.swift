//
//  ExpenseMonth.swift
//  DomusTracker
//
//  Propósito: Define todos os meses disponíveis para rastreamento de despesas
//  Este enum garante consistência ao trabalhar com meses em todo o aplicativo
//

import Foundation

/// ExpenseMonth representa os meses disponíveis para rastreamento de despesas
/// Usar um enum fornece type-safety e previne valores de mês inválidos
/// O aplicativo rastreia despesas de Janeiro até Maio no mínimo
enum ExpenseMonth: String, CaseIterable, Identifiable {
    
    // MARK: - Casos
    
    /// Janeiro
    case janeiro = "Janeiro"
    
    /// Fevereiro
    case fevereiro = "Fevereiro"
    
    /// Março
    case marco = "Março"
    
    /// Abril
    case abril = "Abril"
    
    /// Maio
    case maio = "Maio"
    
    /// Junho - Opcional, pode ser estendido
    case junho = "Junho"
    
    /// Julho - Opcional, pode ser estendido
    case julho = "Julho"
    
    /// Agosto - Opcional, pode ser estendido
    case agosto = "Agosto"
    
    /// Setembro - Opcional, pode ser estendido
    case setembro = "Setembro"
    
    /// Outubro - Opcional, pode ser estendido
    case outubro = "Outubro"
    
    /// Novembro - Opcional, pode ser estendido
    case novembro = "Novembro"
    
    /// Dezembro - Opcional, pode ser estendido
    case dezembro = "Dezembro"
    
    // MARK: - Conformidade com Identifiable
    
    /// Identificador único para cada mês
    /// Necessário para usar meses em Lists e ForEach do SwiftUI
    var id: String { self.rawValue }
    
    // MARK: - Propriedades de Exibição
    
    /// O nome de exibição localizado para o mês
    /// Isso é o que os usuários verão na interface
    var displayName: String {
        return self.rawValue
    }
    
    /// Representação numérica do mês (1-12)
    /// Útil para ordenação e operações de data
    var number: Int {
        switch self {
        case .janeiro:   return 1
        case .fevereiro: return 2
        case .marco:     return 3
        case .abril:     return 4
        case .maio:      return 5
        case .junho:     return 6
        case .julho:     return 7
        case .agosto:    return 8
        case .setembro:  return 9
        case .outubro:   return 10
        case .novembro:  return 11
        case .dezembro:  return 12
        }
    }
    
    /// Abreviação de três letras para o mês
    /// Útil para exibições compactas ou gráficos
    var abbreviation: String {
        switch self {
        case .janeiro:   return "Jan"
        case .fevereiro: return "Fev"
        case .marco:     return "Mar"
        case .abril:     return "Abr"
        case .maio:      return "Mai"
        case .junho:     return "Jun"
        case .julho:     return "Jul"
        case .agosto:    return "Ago"
        case .setembro:  return "Set"
        case .outubro:   return "Out"
        case .novembro:  return "Nov"
        case .dezembro:  return "Dez"
        }
    }
    
    /// Abreviação de uma letra para o mês
    /// Útil para exibições muito compactas
    var initial: String {
        return String(abbreviation.prefix(1))
    }
    
    // MARK: - Métodos Auxiliares
    
    /// Cria um mês a partir de um valor string
    /// Retorna nil se a string não corresponder a nenhum mês
    /// - Parameter string: A string para converter em mês
    /// - Returns: O mês correspondente, ou nil se não encontrado
    static func from(string: String) -> ExpenseMonth? {
        return ExpenseMonth.allCases.first { $0.rawValue == string }
    }
    
    /// Cria um mês a partir de um valor numérico (1-12)
    /// Retorna nil se o número não estiver no intervalo válido
    /// - Parameter number: O número do mês (1 = Janeiro, 12 = Dezembro)
    /// - Returns: O mês correspondente, ou nil se não encontrado
    static func from(number: Int) -> ExpenseMonth? {
        return ExpenseMonth.allCases.first { $0.number == number }
    }
    
    /// Retorna todos os meses como um array
    /// Útil para exibir em pickers ou listas
    static var all: [ExpenseMonth] {
        return ExpenseMonth.allCases
    }
    
    /// Retorna o mês atual baseado na data do sistema
    /// - Returns: O mês atual como um ExpenseMonth
    static var current: ExpenseMonth {
        let currentMonthNumber = Calendar.current.component(.month, from: Date())
        return ExpenseMonth.from(number: currentMonthNumber) ?? .janeiro
    }
    
    /// Retorna o próximo mês na sequência
    /// Volta de Dezembro para Janeiro
    var next: ExpenseMonth {
        let nextNumber = (self.number % 12) + 1
        return ExpenseMonth.from(number: nextNumber) ?? .janeiro
    }
    
    /// Retorna o mês anterior na sequência
    /// Volta de Janeiro para Dezembro
    var previous: ExpenseMonth {
        let prevNumber = self.number == 1 ? 12 : self.number - 1
        return ExpenseMonth.from(number: prevNumber) ?? .dezembro
    }
    
    /// Verifica se este mês vem antes de outro mês
    /// - Parameter other: O mês para comparar
    /// - Returns: True se este mês vem antes do outro mês
    func isBefore(_ other: ExpenseMonth) -> Bool {
        return self.number < other.number
    }
    
    /// Verifica se este mês vem depois de outro mês
    /// - Parameter other: O mês para comparar
    /// - Returns: True se este mês vem depois do outro mês
    func isAfter(_ other: ExpenseMonth) -> Bool {
        return self.number > other.number
    }
}

// MARK: - Conformidade com Comparable

/// Torna ExpenseMonth comparável para que possamos ordenar meses
extension ExpenseMonth: Comparable {
    static func < (lhs: ExpenseMonth, rhs: ExpenseMonth) -> Bool {
        return lhs.number < rhs.number
    }
}

// MARK: - Auxiliar de Preview

#if DEBUG
extension ExpenseMonth {
    /// Mês de exemplo para previews do SwiftUI
    static var sample: ExpenseMonth {
        return .janeiro
    }
    
    /// Array de meses de exemplo para testes (primeiros 5 meses)
    static var samples: [ExpenseMonth] {
        return [.janeiro, .fevereiro, .marco, .abril, .maio]
    }
}
#endif

/*
 GUIA PARA INICIANTES SOBRE O USO DESTE ENUM:
 
 1. Para obter todos os meses para um picker:
    ForEach(ExpenseMonth.allCases) { month in
        Text(month.displayName)
    }
 
 2. Para exibir um mês com sua abreviação:
    Text("\(month.abbreviation) - \(month.displayName)")
 
 3. Para converter uma string em mês:
    if let month = ExpenseMonth.from(string: "Janeiro") {
        // Usar o mês
    }
 
 4. Para obter o mês atual:
    let currentMonth = ExpenseMonth.current
 
 5. Para salvar um mês no Core Data:
    expense.month = ExpenseMonth.janeiro.rawValue
 
 6. Para ler um mês do Core Data:
    if let monthString = expense.month,
       let month = ExpenseMonth.from(string: monthString) {
        // Usar o mês
    }
 
 7. Para ordenar despesas por mês:
    expenses.sorted {
        ExpenseMonth.from(string: $0.month ?? "")?.number ?? 0 <
        ExpenseMonth.from(string: $1.month ?? "")?.number ?? 0
    }
 
 8. Para navegar entre meses:
    let nextMonth = currentMonth.next
    let previousMonth = currentMonth.previous
 
 POR QUE USAR UM ENUM PARA MESES?
 - Type safety: Previne nomes de mês inválidos
 - Localização: Fácil de mudar nomes de mês para diferentes idiomas
 - Ordenação: Ordenação de mês integrada com a propriedade number
 - Consistência: Mesmos nomes de mês em todo o aplicativo
 - Utilitários: Métodos auxiliares para operações comuns
 */

// Feito com Bob
