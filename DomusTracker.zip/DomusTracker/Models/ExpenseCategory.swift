//
//  ExpenseCategory.swift
//  DomusTracker
//
//  Propósito: Define todas as categorias de despesas disponíveis para o aplicativo
//  Este enum garante consistência e type-safety ao trabalhar com categorias
//

import SwiftUI

/// ExpenseCategory representa todas as categorias possíveis para despesas
/// Usar um enum garante que apenas categorias válidas possam ser usadas em todo o aplicativo
/// Isso previne erros de digitação e torna o código mais manutenível
enum ExpenseCategory: String, CaseIterable, Identifiable {
    
    // MARK: - Casos
    
    /// Despesas de eletricidade (Energia elétrica)
    case energia = "Energia"
    
    /// Despesas de serviço de internet
    case internet = "Internet"
    
    /// Despesas de água (Água)
    case agua = "Água"
    
    /// Serviços de assinatura (Netflix, Spotify, etc.)
    case assinaturas = "Assinaturas"
    
    /// Pagamentos de aluguel ou hipoteca (Aluguel)
    case aluguel = "Aluguel"
    
    /// Despesas de compras de supermercado (Mercado)
    case mercado = "Mercado"
    
    /// Cursos educacionais e treinamentos (Cursos)
    case cursos = "Cursos"
    
    /// Atividades de entretenimento e lazer (Lazer)
    case lazer = "Lazer"
    
    // MARK: - Conformidade com Identifiable
    
    /// Identificador único para cada categoria
    /// Isso é necessário para usar categorias em Lists e ForEach do SwiftUI
    var id: String { self.rawValue }
    
    // MARK: - Propriedades de Exibição
    
    /// O nome de exibição localizado para a categoria
    /// Isso é o que os usuários verão na interface
    var displayName: String {
        return self.rawValue
    }
    
    /// Nome do ícone SF Symbol para cada categoria
    /// SF Symbols são o sistema de ícones integrado da Apple
    /// Eles se adaptam automaticamente a diferentes tamanhos e pesos
    var icon: String {
        switch self {
        case .energia:
            return "bolt.fill"              // Raio para eletricidade
        case .internet:
            return "wifi"                   // Símbolo WiFi para internet
        case .agua:
            return "drop.fill"              // Gota d'água para água
        case .assinaturas:
            return "star.fill"              // Estrela para assinaturas
        case .aluguel:
            return "house.fill"             // Casa para aluguel
        case .mercado:
            return "cart.fill"              // Carrinho de compras para supermercado
        case .cursos:
            return "book.fill"              // Livro para cursos
        case .lazer:
            return "gamecontroller.fill"    // Controle de jogo para lazer
        }
    }
    
    /// Cor associada a cada categoria
    /// Usar cores distintas ajuda os usuários a identificar rapidamente as categorias
    var color: Color {
        switch self {
        case .energia:
            return .yellow      // Amarelo como eletricidade/luz
        case .internet:
            return .blue        // Azul como digital/tecnologia
        case .agua:
            return .cyan        // Ciano como água
        case .assinaturas:
            return .purple      // Roxo para serviços premium
        case .aluguel:
            return .orange      // Laranja para casa/aconchego
        case .mercado:
            return .green       // Verde como produtos frescos
        case .cursos:
            return .indigo      // Índigo para educação/conhecimento
        case .lazer:
            return .pink        // Rosa para diversão/entretenimento
        }
    }
    
    /// Representação emoji para cada categoria
    /// Fornece uma alternativa visual e divertida aos SF Symbols
    var emoji: String {
        switch self {
        case .energia:
            return "⚡️"
        case .internet:
            return "🌐"
        case .agua:
            return "💧"
        case .assinaturas:
            return "⭐️"
        case .aluguel:
            return "🏠"
        case .mercado:
            return "🛒"
        case .cursos:
            return "📚"
        case .lazer:
            return "🎮"
        }
    }
    
    // MARK: - Métodos Auxiliares
    
    /// Cria uma categoria a partir de um valor string
    /// Retorna nil se a string não corresponder a nenhuma categoria
    /// - Parameter string: A string para converter em categoria
    /// - Returns: A categoria correspondente, ou nil se não encontrada
    static func from(string: String) -> ExpenseCategory? {
        return ExpenseCategory.allCases.first { $0.rawValue == string }
    }
    
    /// Retorna todas as categorias como um array
    /// Útil para exibir em pickers ou listas
    static var all: [ExpenseCategory] {
        return ExpenseCategory.allCases
    }
}

// MARK: - Auxiliar de Preview

#if DEBUG
extension ExpenseCategory {
    /// Categoria de exemplo para previews do SwiftUI
    static var sample: ExpenseCategory {
        return .energia
    }
    
    /// Array de categorias de exemplo para testes
    static var samples: [ExpenseCategory] {
        return [.energia, .internet, .agua, .mercado]
    }
}
#endif

/*
 GUIA PARA INICIANTES SOBRE O USO DESTE ENUM:
 
 1. Para obter todas as categorias para um picker:
    ForEach(ExpenseCategory.allCases) { category in
        Text(category.displayName)
    }
 
 2. Para exibir uma categoria com seu ícone:
    Label(category.displayName, systemImage: category.icon)
        .foregroundColor(category.color)
 
 3. Para converter uma string em categoria:
    if let category = ExpenseCategory.from(string: "Energia") {
        // Usar a categoria
    }
 
 4. Para salvar uma categoria no Core Data:
    expense.category = ExpenseCategory.energia.rawValue
 
 5. Para ler uma categoria do Core Data:
    if let categoryString = expense.category,
       let category = ExpenseCategory.from(string: categoryString) {
        // Usar a categoria
    }
 
 POR QUE USAR UM ENUM?
 - Type safety: O compilador previne categorias inválidas
 - Autocomplete: Xcode sugere categorias válidas enquanto você digita
 - Refatoração: Fácil de renomear ou adicionar categorias
 - Consistência: Mesmos nomes de categoria em todo o aplicativo
 - Sem erros de digitação: Não pode usar acidentalmente "Energya" em vez de "Energia"
 */

// Feito com Bob
