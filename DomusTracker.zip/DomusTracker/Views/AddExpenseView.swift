//
//  AddExpenseView.swift
//  DomusTracker
//
//  Propósito: View de formulário para adicionar uma nova despesa
//  Fornece validação de entrada e mensagens de erro amigáveis ao usuário
//

import SwiftUI
import CoreData

/// AddExpenseView fornece um formulário para criar uma nova despesa
/// Inclui validação e tratamento de erros
struct AddExpenseView: View {
    
    // MARK: - Ambiente
    
    /// Contexto de objeto gerenciado do Core Data
    @Environment(\.managedObjectContext) private var viewContext
    
    /// Ação de dismiss para fechar a sheet
    @Environment(\.dismiss) private var dismiss
    
    // MARK: - Estado
    
    /// ViewModel para gerenciar operações de despesas
    @StateObject private var viewModel: ExpenseViewModel
    
    /// Campos do formulário
    @State private var selectedCategory: ExpenseCategory = .energia
    @State private var selectedMonth: ExpenseMonth
    @State private var amount: String = ""
    @State private var description: String = ""
    
    /// Estado da UI
    @State private var showingError = false
    @State private var showingSuccess = false
    @State private var isProcessing = false
    
    /// Estado de foco para campos de texto
    @FocusState private var focusedField: Field?
    
    /// Mês pré-selecionado (opcional)
    let preselectedMonth: ExpenseMonth?
    
    // MARK: - Enum de Campo
    
    /// Enum para rastrear qual campo está focado
    enum Field {
        case amount
        case description
    }
    
    // MARK: - Inicialização
    
    init(preselectedMonth: ExpenseMonth? = nil) {
        self.preselectedMonth = preselectedMonth
        
        // Inicializa com mês pré-selecionado ou mês atual
        _selectedMonth = State(initialValue: preselectedMonth ?? ExpenseMonth.current)
        
        // Inicializa o ViewModel
        let context = PersistenceController.shared.container.viewContext
        _viewModel = StateObject(wrappedValue: ExpenseViewModel(context: context))
    }
    
    // MARK: - Corpo
    
    var body: some View {
        NavigationView {
            Form {
                // Seção de categoria
                Section(header: Text("Categoria")) {
                    CategoryPickerGrid(
                        selectedCategory: $selectedCategory,
                        title: nil
                    )
                }
                
                // Seção de mês
                Section(header: Text("Mês")) {
                    MonthPicker(
                        selectedMonth: $selectedMonth,
                        title: nil
                    )
                }
                
                // Seção de valor
                Section(header: Text("Valor")) {
                    HStack {
                        Text("R$")
                            .foregroundColor(.secondary)
                        
                        TextField("0,00", text: $amount)
                            .keyboardType(.decimalPad)
                            .focused($focusedField, equals: .amount)
                            .onChange(of: amount) { newValue in
                                // Formata a entrada enquanto o usuário digita
                                amount = formatAmountInput(newValue)
                            }
                    }
                }
                .listRowBackground(amountFieldBackground)
                
                // Seção de descrição
                Section(header: Text("Descrição (Opcional)")) {
                    TextEditor(text: $description)
                        .frame(minHeight: 100)
                        .focused($focusedField, equals: .description)
                }
                
                // Contagem de caracteres para descrição
                if !description.isEmpty {
                    Section {
                        Text("\(description.count)/200 caracteres")
                            .font(.caption)
                            .foregroundColor(description.count > 200 ? .red : .secondary)
                    }
                }
            }
            .navigationTitle("Nova Despesa")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Salvar") {
                        saveExpense()
                    }
                    .disabled(isProcessing || !isFormValid)
                }
                
                // Barra de ferramentas do teclado
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Concluído") {
                        focusedField = nil
                    }
                }
            }
            .alert("Erro", isPresented: $showingError) {
                Button("OK", role: .cancel) {
                    viewModel.clearMessages()
                }
            } message: {
                Text(viewModel.errorMessage ?? "Ocorreu um erro ao salvar a despesa.")
            }
            .onChange(of: viewModel.errorMessage) { error in
                if error != nil {
                    showingError = true
                    isProcessing = false
                }
            }
            .onChange(of: viewModel.successMessage) { success in
                if success != nil {
                    showingSuccess = true
                    // Dismiss após um pequeno atraso
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    // MARK: - Propriedades Computadas
    
    /// Cor de fundo para campo de valor baseada na validação
    private var amountFieldBackground: some View {
        Group {
            if !amount.isEmpty && !isAmountValid {
                Color.red.opacity(0.1)
            } else {
                Color(.systemBackground)
            }
        }
    }
    
    /// Verifica se o formulário é válido
    private var isFormValid: Bool {
        return isAmountValid && isDescriptionValid
    }
    
    /// Verifica se o valor é válido
    private var isAmountValid: Bool {
        guard !amount.isEmpty else { return false }
        guard let value = parseAmount(amount) else { return false }
        return value > 0
    }
    
    /// Verifica se a descrição é válida
    private var isDescriptionValid: Bool {
        return description.count <= 200
    }
    
    // MARK: - Métodos
    
    /// Salva a despesa
    private func saveExpense() {
        // Dismiss do teclado
        focusedField = nil
        
        // Valida o formulário
        guard isFormValid else {
            viewModel.errorMessage = "Por favor, preencha todos os campos corretamente."
            showingError = true
            return
        }
        
        // Analisa o valor
        guard let amountValue = parseAmount(amount) else {
            viewModel.errorMessage = "Valor inválido. Use apenas números e vírgula para decimais."
            showingError = true
            return
        }
        
        // Define estado de processamento
        isProcessing = true
        
        // Cria a despesa
        let trimmedDescription = description.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalDescription = trimmedDescription.isEmpty ? nil : trimmedDescription
        
        let expense = viewModel.createExpense(
            category: selectedCategory,
            month: selectedMonth,
            amount: amountValue,
            description: finalDescription
        )
        
        if expense != nil {
            // Sucesso - o handler onChange irá dismiss a view
            isProcessing = false
        } else {
            // Erro - o handler onChange irá mostrar o erro
            isProcessing = false
        }
    }
    
    /// Formata a entrada de valor enquanto o usuário digita
    private func formatAmountInput(_ input: String) -> String {
        // Remove todos os caracteres não numéricos exceto vírgula e ponto
        let filtered = input.filter { "0123456789,.".contains($0) }
        
        // Substitui ponto por vírgula (formato brasileiro)
        let withComma = filtered.replacingOccurrences(of: ".", with: ",")
        
        // Garante apenas uma vírgula
        let components = withComma.components(separatedBy: ",")
        if components.count > 2 {
            return components[0] + "," + components[1]
        }
        
        // Limita casas decimais a 2
        if components.count == 2 {
            let decimals = String(components[1].prefix(2))
            return components[0] + "," + decimals
        }
        
        return withComma
    }
    
    /// Analisa a string de valor para um Double
    private func parseAmount(_ input: String) -> Double? {
        // Substitui vírgula por ponto para análise
        let normalized = input.replacingOccurrences(of: ",", with: ".")
        return Double(normalized)
    }
}

// MARK: - Previews

#if DEBUG
struct AddExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Sem mês pré-selecionado
            AddExpenseView()
                .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
                .previewDisplayName("Default")
            
            // Com mês pré-selecionado
            AddExpenseView(preselectedMonth: .janeiro)
                .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
                .previewDisplayName("Janeiro Preselected")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES SOBRE ESTA VIEW:
 
 1. Propósito:
    - Fornecer um formulário para adicionar novas despesas
    - Validar entrada do usuário
    - Salvar no Core Data
    - Lidar com erros de forma elegante
 
 2. Campos do Formulário:
    - Categoria: Obrigatório, usa CategoryPickerGrid
    - Mês: Obrigatório, usa MonthPicker
    - Valor: Obrigatório, validado para números positivos
    - Descrição: Opcional, máximo 200 caracteres
 
 3. Validação:
    - Valor deve ser > 0
    - Descrição deve ter <= 200 caracteres
    - Botão Salvar desabilitado até formulário ser válido
    - Feedback visual (fundo vermelho) para valor inválido
 
 4. Experiência do Usuário:
    - Formatação de entrada em tempo real para valor
    - Contador de caracteres para descrição
    - Barra de ferramentas do teclado com botão "Concluído"
    - Auto-dismiss em sucesso
    - Alertas de erro para falhas
 
 5. Fluxo de Dados:
    - Usuário preenche formulário
    - Toca "Salvar"
    - ViewModel cria despesa
    - Sucesso: View é dismissed
    - Erro: Alerta mostra mensagem de erro
 
 6. Formatação de Entrada:
    - Valor: Formata automaticamente como moeda brasileira
    - Aceita vírgula ou ponto como separador decimal
    - Converte para vírgula (padrão brasileiro)
    - Limita a 2 casas decimais
 
 7. Mês Pré-selecionado:
    - Pode ser passado da view pai
    - Útil ao adicionar de uma view de mês específico
    - Volta para mês atual se não fornecido
 
 8. Gerenciamento de Teclado:
    - @FocusState rastreia qual campo está focado
    - Barra de ferramentas do teclado fornece botão "Concluído"
    - Dismiss do teclado antes de salvar
 
 POR QUE ESTE DESIGN?
 - Simples: Formulário claro e focado
 - Validado: Previne dados inválidos
 - Tolerante: Formata entrada automaticamente
 - Informativo: Mostra contagens de caracteres e validação
 - Responsivo: Feedback em tempo real
 - Seguro: Confirmação e tratamento de erros
 
 REGRAS DE VALIDAÇÃO:
 - Valor: Deve ser número positivo
 - Descrição: Opcional, máximo 200 caracteres
 - Categoria: Sempre válida (picker)
 - Mês: Sempre válido (picker)
 
 FORMATAÇÃO DE ENTRADA:
 - "150" → "150"
 - "150.50" → "150,50"
 - "150,5" → "150,5"
 - "150,505" → "150,50" (limitado a 2 decimais)
 */

// Feito com Bob