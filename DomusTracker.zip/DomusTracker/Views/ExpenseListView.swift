//
//  ExpenseListView.swift
//  DomusTracker
//
//  Propósito: Exibe uma lista de despesas, opcionalmente filtrada por mês
//  Usuários podem visualizar, adicionar, editar e excluir despesas desta visualização
//

import SwiftUI
import CoreData

/// ExpenseListView mostra despesas com filtragem e operações CRUD
/// Pode mostrar todas as despesas ou filtrar por um mês específico
struct ExpenseListView: View {
    
    // MARK: - Ambiente
    
    /// Contexto de objeto gerenciado do Core Data
    @Environment(\.managedObjectContext) private var viewContext
    
    // MARK: - Estado
    
    /// ViewModel para gerenciar operações de despesas
    @StateObject private var viewModel: ExpenseViewModel
    
    /// Filtro de mês opcional - se nil, mostra todas as despesas
    let selectedMonth: ExpenseMonth?
    
    /// Controla a apresentação da folha de adicionar despesa
    @State private var showingAddExpense = false
    
    /// Controla a apresentação da folha de editar despesa
    @State private var showingEditExpense = false
    
    /// A despesa atualmente sendo editada
    @State private var expenseToEdit: Expense?
    
    /// Controla a apresentação de alertas de erro
    @State private var showingError = false
    
    /// Controla a apresentação da confirmação de exclusão
    @State private var showingDeleteConfirmation = false
    
    /// A despesa a ser excluída
    @State private var expenseToDelete: Expense?
    
    // MARK: - Requisição de Busca
    
    /// Busca despesas do Core Data
    /// Se selectedMonth for fornecido, filtra por esse mês
    /// Caso contrário, busca todas as despesas
    @FetchRequest private var expenses: FetchedResults<Expense>
    
    // MARK: - Inicialização
    
    init(selectedMonth: ExpenseMonth?) {
        self.selectedMonth = selectedMonth
        
        // Inicializa o ViewModel
        let context = PersistenceController.shared.container.viewContext
        _viewModel = StateObject(wrappedValue: ExpenseViewModel(context: context))
        
        // Configura a requisição de busca baseado em se temos um filtro de mês
        if let month = selectedMonth {
            // Busca despesas para mês específico
            _expenses = FetchRequest(
                sortDescriptors: [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)],
                predicate: NSPredicate(format: "month == %@", month.rawValue),
                animation: .default
            )
        } else {
            // Busca todas as despesas
            _expenses = FetchRequest(
                sortDescriptors: [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)],
                animation: .default
            )
        }
    }
    
    // MARK: - Corpo
    
    var body: some View {
        ZStack {
            if expenses.isEmpty {
                // Mostra estado vazio quando não há despesas
                emptyState
            } else {
                // Mostra lista de despesas
                expenseList
            }
        }
        .navigationTitle(navigationTitle)
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                addButton
            }
        }
        .sheet(isPresented: $showingAddExpense) {
            AddExpenseView(preselectedMonth: selectedMonth)
        }
        .sheet(item: $expenseToEdit) { expense in
            EditExpenseView(expense: expense)
        }
        .alert("Erro", isPresented: $showingError) {
            Button("OK", role: .cancel) {
                viewModel.clearMessages()
            }
        } message: {
            Text(viewModel.errorMessage ?? "Ocorreu um erro desconhecido.")
        }
        .alert("Excluir Despesa", isPresented: $showingDeleteConfirmation) {
            Button("Cancelar", role: .cancel) {
                expenseToDelete = nil
            }
            Button("Excluir", role: .destructive) {
                if let expense = expenseToDelete {
                    deleteExpense(expense)
                }
            }
        } message: {
            Text("Tem certeza que deseja excluir esta despesa? Esta ação não pode ser desfeita.")
        }
        .onChange(of: viewModel.errorMessage) { error in
            if error != nil {
                showingError = true
            }
        }
    }
    
    // MARK: - Subvisualizações
    
    /// Título de navegação baseado em se estamos filtrando por mês
    private var navigationTitle: String {
        if let month = selectedMonth {
            return month.displayName
        } else {
            return "Todas as Despesas"
        }
    }
    
    /// Botão adicionar na barra de ferramentas
    private var addButton: some View {
        Button(action: {
            showingAddExpense = true
        }) {
            Image(systemName: "plus")
        }
    }
    
    /// Visualização de estado vazio
    private var emptyState: some View {
        Group {
            if let month = selectedMonth {
                EmptyStateView.noExpensesInMonth(month) {
                    showingAddExpense = true
                }
            } else {
                EmptyStateView.noExpenses {
                    showingAddExpense = true
                }
            }
        }
    }
    
    /// Lista de despesas
    private var expenseList: some View {
        List {
            // Seção de resumo
            Section {
                summaryCard
            }
            
            // Seção de despesas
            Section(header: Text("Despesas")) {
                ForEach(expenses) { expense in
                    ExpenseRow(expense: expense, style: .withDescription)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            expenseToEdit = expense
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            // Ação de exclusão
                            Button(role: .destructive) {
                                expenseToDelete = expense
                                showingDeleteConfirmation = true
                            } label: {
                                Label("Excluir", systemImage: "trash")
                            }
                            
                            // Ação de edição
                            Button {
                                expenseToEdit = expense
                            } label: {
                                Label("Editar", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                }
            }
        }
    }
    
    /// Cartão de resumo mostrando total e contagem
    private var summaryCard: some View {
        VStack(spacing: 8) {
            // Valor total
            HStack {
                Text("Total")
                    .font(.headline)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                Text(calculateTotal().asCurrency)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
            }
            
            // Contagem de despesas
            HStack {
                Text("Despesas")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                Text("\(expenses.count)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.accentColor.opacity(0.1))
        )
    }
    
    // MARK: - Métodos
    
    /// Calcula o total de todas as despesas exibidas
    private func calculateTotal() -> Double {
        expenses.reduce(0) { $0 + $1.amountValue }
    }
    
    /// Exclui uma despesa
    private func deleteExpense(_ expense: Expense) {
        let success = viewModel.deleteExpense(expense)
        if !success {
            showingError = true
        }
        expenseToDelete = nil
    }
}

// MARK: - Layout Alternativo com Categorias

/// ExpenseListViewGrouped agrupa despesas por categoria
/// Isso fornece uma maneira diferente de visualizar despesas
struct ExpenseListViewGrouped: View {
    
    // MARK: - Ambiente
    
    @Environment(\.managedObjectContext) private var viewContext
    
    // MARK: - Estado
    
    @StateObject private var viewModel: ExpenseViewModel
    let selectedMonth: ExpenseMonth?
    @State private var showingAddExpense = false
    
    // MARK: - Requisição de Busca
    
    @FetchRequest private var expenses: FetchedResults<Expense>
    
    // MARK: - Inicialização
    
    init(selectedMonth: ExpenseMonth?) {
        self.selectedMonth = selectedMonth
        
        let context = PersistenceController.shared.container.viewContext
        _viewModel = StateObject(wrappedValue: ExpenseViewModel(context: context))
        
        if let month = selectedMonth {
            _expenses = FetchRequest(
                sortDescriptors: [
                    NSSortDescriptor(keyPath: \Expense.category, ascending: true),
                    NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)
                ],
                predicate: NSPredicate(format: "month == %@", month.rawValue),
                animation: .default
            )
        } else {
            _expenses = FetchRequest(
                sortDescriptors: [
                    NSSortDescriptor(keyPath: \Expense.category, ascending: true),
                    NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)
                ],
                animation: .default
            )
        }
    }
    
    // MARK: - Corpo
    
    var body: some View {
        List {
            // Agrupa despesas por categoria
            ForEach(ExpenseCategory.allCases) { category in
                let categoryExpenses = expenses.filter { $0.categoryEnum == category }
                
                if !categoryExpenses.isEmpty {
                    Section(header: CategoryLabel(category: category)) {
                        ForEach(categoryExpenses) { expense in
                            ExpenseRowCompact(expense: expense)
                        }
                    }
                }
            }
        }
        .navigationTitle(selectedMonth?.displayName ?? "Todas as Despesas")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: { showingAddExpense = true }) {
                    Image(systemName: "plus")
                }
            }
        }
        .sheet(isPresented: $showingAddExpense) {
            AddExpenseView(preselectedMonth: selectedMonth)
        }
    }
}

// MARK: - Pré-visualizações

#if DEBUG
struct ExpenseListView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Com filtro de mês
            NavigationView {
                ExpenseListView(selectedMonth: .janeiro)
            }
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
            .previewDisplayName("Janeiro")
            
            // Todas as despesas
            NavigationView {
                ExpenseListView(selectedMonth: nil)
            }
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
            .previewDisplayName("Todas")
            
            // Agrupado por categoria
            NavigationView {
                ExpenseListViewGrouped(selectedMonth: .janeiro)
            }
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
            .previewDisplayName("Agrupado")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES DESTA VISUALIZAÇÃO:
 
 1. Propósito:
    - Exibir despesas para um mês específico ou todas as despesas
    - Permitir adicionar, editar e excluir despesas
    - Mostrar informações de resumo (total, contagem)
 
 2. Fluxo de Dados:
    - @FetchRequest busca despesas do Core Data
    - Predicado filtra por mês se fornecido
    - ViewModel trata operações CRUD
 
 3. Interações do Usuário:
    - Toque na despesa para editar
    - Deslize para a esquerda para ações de excluir/editar
    - Toque no botão + para adicionar nova despesa
    - Puxe para atualizar (automático com List)
 
 4. Recursos Principais:
    - Cartão de resumo com total e contagem
    - Estado vazio quando não há despesas
    - Ações de deslizar para editar/excluir rápido
    - Diálogo de confirmação antes de excluir
    - Tratamento de erro com alertas
 
 5. Navegação:
    - Apresentado como folha do MonthListView ou ContentView
    - Mostra AddExpenseView para novas despesas
    - Mostra EditExpenseView para edição
 
 6. Filtragem:
    - Se selectedMonth for fornecido: mostra apenas despesas daquele mês
    - Se selectedMonth for nil: mostra todas as despesas
    - Predicado em @FetchRequest trata a filtragem
 
 7. Layout Alternativo:
    - ExpenseListViewGrouped agrupa por categoria
    - Útil para ver padrões de gastos
    - Mesma funcionalidade, organização diferente
 
 POR QUE ESTE DESIGN?
 - Flexível: Funciona para um mês ou todos os meses
 - Intuitivo: Padrões iOS padrão (deslizar, tocar, folhas)
 - Informativo: Cartão de resumo fornece contexto
 - Seguro: Confirmação antes de excluir
 - Responsivo: Atualizações em tempo real do Core Data
 
 AÇÕES DE DESLIZAR:
 - Deslize para a esquerda para revelar ações
 - Botão vermelho de exclusão (destrutivo)
 - Botão azul de edição
 - allowsFullSwipe: false previne exclusões acidentais
 
 TRATAMENTO DE ERROS:
 - ViewModel fornece mensagens de erro
 - Alerta mostra erros ao usuário
 - Usuário pode dispensar e tentar novamente
 */

// Feito com Bob