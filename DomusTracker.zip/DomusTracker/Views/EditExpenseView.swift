//
//  EditExpenseView.swift
//  DomusTracker
//
//  Purpose: Form view for editing an existing expense
//  Provides input validation and user-friendly error messages
//

import SwiftUI
import CoreData

/// EditExpenseView provides a form to edit an existing expense
/// It includes validation and error handling
struct EditExpenseView: View {
    
    // MARK: - Environment
    
    /// Core Data managed object context
    @Environment(\.managedObjectContext) private var viewContext
    
    /// Dismiss action to close the sheet
    @Environment(\.dismiss) private var dismiss
    
    // MARK: - State
    
    /// ViewModel for managing expense operations
    @StateObject private var viewModel: ExpenseViewModel
    
    /// The expense being edited
    let expense: Expense
    
    /// Form fields (initialized from expense)
    @State private var selectedCategory: ExpenseCategory
    @State private var selectedMonth: ExpenseMonth
    @State private var amount: String
    @State private var description: String
    
    /// UI state
    @State private var showingError = false
    @State private var showingSuccess = false
    @State private var isProcessing = false
    @State private var showingDeleteConfirmation = false
    
    /// Focus state for text fields
    @FocusState private var focusedField: Field?
    
    // MARK: - Field Enum
    
    /// Enum to track which field is focused
    enum Field {
        case amount
        case description
    }
    
    // MARK: - Initialization
    
    init(expense: Expense) {
        self.expense = expense
        
        // Initialize form fields from expense
        _selectedCategory = State(initialValue: expense.categoryEnum ?? .energia)
        _selectedMonth = State(initialValue: expense.monthEnum ?? .janeiro)
        
        // Format amount for display
        let amountValue = expense.amountValue
        let amountString = String(format: "%.2f", amountValue).replacingOccurrences(of: ".", with: ",")
        _amount = State(initialValue: amountString)
        
        _description = State(initialValue: expense.descriptionText ?? "")
        
        // Initialize ViewModel
        let context = PersistenceController.shared.container.viewContext
        _viewModel = StateObject(wrappedValue: ExpenseViewModel(context: context))
    }
    
    // MARK: - Body
    
    var body: some View {
        NavigationView {
            Form {
                // Category section
                Section(header: Text("Categoria")) {
                    CategoryPickerGrid(
                        selectedCategory: $selectedCategory,
                        title: nil
                    )
                }
                
                // Month section
                Section(header: Text("Mês")) {
                    MonthPicker(
                        selectedMonth: $selectedMonth,
                        title: nil
                    )
                }
                
                // Amount section
                Section(header: Text("Valor")) {
                    HStack {
                        Text("R$")
                            .foregroundColor(.secondary)
                        
                        TextField("0,00", text: $amount)
                            .keyboardType(.decimalPad)
                            .focused($focusedField, equals: .amount)
                            .onChange(of: amount) { newValue in
                                // Format the input as the user types
                                amount = formatAmountInput(newValue)
                            }
                    }
                }
                .listRowBackground(amountFieldBackground)
                
                // Description section
                Section(header: Text("Descrição (Opcional)")) {
                    TextEditor(text: $description)
                        .frame(minHeight: 100)
                        .focused($focusedField, equals: .description)
                }
                
                // Character count for description
                if !description.isEmpty {
                    Section {
                        Text("\(description.count)/200 caracteres")
                            .font(.caption)
                            .foregroundColor(description.count > 200 ? .red : .secondary)
                    }
                }
                
                // Metadata section
                Section(header: Text("Informações")) {
                    HStack {
                        Text("Criado em")
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(expense.formattedCreatedDateTime)
                            .foregroundColor(.primary)
                            .font(.caption)
                    }
                    
                    if let updatedAt = expense.updatedAt,
                       let createdAt = expense.createdAt,
                       !Calendar.current.isDate(updatedAt, inSameDayAs: createdAt) {
                        HStack {
                            Text("Atualizado em")
                                .foregroundColor(.secondary)
                            Spacer()
                            Text(expense.formattedUpdatedDateTime)
                                .foregroundColor(.primary)
                                .font(.caption)
                        }
                    }
                }
                
                // Delete section
                Section {
                    Button(role: .destructive) {
                        showingDeleteConfirmation = true
                    } label: {
                        HStack {
                            Spacer()
                            Label("Excluir Despesa", systemImage: "trash")
                            Spacer()
                        }
                    }
                }
            }
            .navigationTitle("Editar Despesa")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Salvar") {
                        saveChanges()
                    }
                    .disabled(isProcessing || !isFormValid || !hasChanges)
                }
                
                // Keyboard toolbar
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Concluído") {
                        focusedField = nil
                    }
                }
            }
            .alert("Erro", isPresented: $showingError) {
                Button("OK", role: .cancel) {
                    viewModel.clearMessages()
                }
            } message: {
                Text(viewModel.errorMessage ?? "Ocorreu um erro ao salvar as alterações.")
            }
            .alert("Excluir Despesa", isPresented: $showingDeleteConfirmation) {
                Button("Cancelar", role: .cancel) { }
                Button("Excluir", role: .destructive) {
                    deleteExpense()
                }
            } message: {
                Text("Tem certeza que deseja excluir esta despesa? Esta ação não pode ser desfeita.")
            }
            .onChange(of: viewModel.errorMessage) { error in
                if error != nil {
                    showingError = true
                    isProcessing = false
                }
            }
            .onChange(of: viewModel.successMessage) { success in
                if success != nil {
                    showingSuccess = true
                    // Dismiss after a short delay
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        dismiss()
                    }
                }
            }
        }
    }
    
    // MARK: - Computed Properties
    
    /// Background color for amount field based on validation
    private var amountFieldBackground: some View {
        Group {
            if !amount.isEmpty && !isAmountValid {
                Color.red.opacity(0.1)
            } else {
                Color(.systemBackground)
            }
        }
    }
    
    /// Checks if the form is valid
    private var isFormValid: Bool {
        return isAmountValid && isDescriptionValid
    }
    
    /// Checks if the amount is valid
    private var isAmountValid: Bool {
        guard !amount.isEmpty else { return false }
        guard let value = parseAmount(amount) else { return false }
        return value > 0
    }
    
    /// Checks if the description is valid
    private var isDescriptionValid: Bool {
        return description.count <= 200
    }
    
    /// Checks if any changes were made
    private var hasChanges: Bool {
        let currentAmount = parseAmount(amount) ?? 0
        let originalAmount = expense.amountValue
        let currentDescription = description.trimmingCharacters(in: .whitespacesAndNewlines)
        let originalDescription = expense.descriptionText ?? ""
        
        return selectedCategory != expense.categoryEnum ||
               selectedMonth != expense.monthEnum ||
               abs(currentAmount - originalAmount) > 0.001 ||
               currentDescription != originalDescription
    }
    
    // MARK: - Methods
    
    /// Saves the changes to the expense
    private func saveChanges() {
        // Dismiss keyboard
        focusedField = nil
        
        // Validate form
        guard isFormValid else {
            viewModel.errorMessage = "Por favor, preencha todos os campos corretamente."
            showingError = true
            return
        }
        
        // Check if there are changes
        guard hasChanges else {
            dismiss()
            return
        }
        
        // Parse amount
        guard let amountValue = parseAmount(amount) else {
            viewModel.errorMessage = "Valor inválido. Use apenas números e vírgula para decimais."
            showingError = true
            return
        }
        
        // Set processing state
        isProcessing = true
        
        // Update expense
        let trimmedDescription = description.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalDescription = trimmedDescription.isEmpty ? nil : trimmedDescription
        
        let success = viewModel.updateExpense(
            expense,
            category: selectedCategory,
            month: selectedMonth,
            amount: amountValue,
            description: finalDescription
        )
        
        if !success {
            // Error - the onChange handler will show the error
            isProcessing = false
        } else {
            // Success - the onChange handler will dismiss the view
            isProcessing = false
        }
    }
    
    /// Deletes the expense
    private func deleteExpense() {
        isProcessing = true
        
        let success = viewModel.deleteExpense(expense)
        
        if success {
            // Dismiss immediately on successful delete
            dismiss()
        } else {
            // Show error
            isProcessing = false
            showingError = true
        }
    }
    
    /// Formats the amount input as the user types
    private func formatAmountInput(_ input: String) -> String {
        // Remove all non-numeric characters except comma and dot
        let filtered = input.filter { "0123456789,.".contains($0) }
        
        // Replace dot with comma (Brazilian format)
        let withComma = filtered.replacingOccurrences(of: ".", with: ",")
        
        // Ensure only one comma
        let components = withComma.components(separatedBy: ",")
        if components.count > 2 {
            return components[0] + "," + components[1]
        }
        
        // Limit decimal places to 2
        if components.count == 2 {
            let decimals = String(components[1].prefix(2))
            return components[0] + "," + decimals
        }
        
        return withComma
    }
    
    /// Parses the amount string to a Double
    private func parseAmount(_ input: String) -> Double? {
        // Replace comma with dot for parsing
        let normalized = input.replacingOccurrences(of: ",", with: ".")
        return Double(normalized)
    }
}

// MARK: - Previews

#if DEBUG
struct EditExpenseView_Previews: PreviewProvider {
    static var previews: some View {
        let context = PersistenceController.preview.container.viewContext
        let expense = Expense.create(
            in: context,
            category: .energia,
            month: .janeiro,
            amount: 150.50,
            description: "Conta de luz do mês de janeiro"
        )
        
        return EditExpenseView(expense: expense)
            .environment(\.managedObjectContext, context)
    }
}
#endif

/*
 GUIA PARA INICIANTES DESTA VISUALIZAÇÃO:
 
 1. Propósito:
    - Editar uma despesa existente
    - Validar entrada do usuário
    - Salvar alterações no Core Data
    - Permitir exclusão da despesa
    - Tratar erros de forma elegante
 
 2. Campos do Formulário:
    - Categoria: Pré-preenchida da despesa
    - Mês: Pré-preenchido da despesa
    - Valor: Pré-preenchido e formatado
    - Descrição: Pré-preenchida da despesa
 
 3. Validação:
    - Mesmas regras que AddExpenseView
    - Valor deve ser > 0
    - Descrição deve ter <= 200 caracteres
    - Botão Salvar desabilitado até o formulário ser válido
 
 4. Detecção de Alterações:
    - Rastreia se alguma alteração foi feita
    - Botão Salvar desabilitado se não houver alterações
    - Previne salvamentos desnecessários
 
 5. Experiência do Usuário:
    - Mostra carimbos de data/hora de criação e atualização
    - Botão de exclusão na parte inferior (estilo destrutivo)
    - Confirmação antes de excluir
    - Auto-dispensa em caso de sucesso
    - Alertas de erro para falhas
 
 6. Fluxo de Dados:
    - Despesa passada da visualização pai
    - Formulário inicializado com dados da despesa
    - Usuário faz alterações
    - Toque em "Salvar" para salvar ou "Excluir" para excluir
    - Sucesso: Visualização é dispensada
    - Erro: Alerta mostra mensagem de erro
 
 7. Diferenças em relação ao AddExpenseView:
    - Pré-preenchido com dados existentes
    - Mostra metadados (datas de criação/atualização)
    - Possui funcionalidade de exclusão
    - Rastreia alterações para prevenir salvamentos desnecessários
 
 8. Funcionalidade de Exclusão:
    - Botão destrutivo vermelho
    - Diálogo de confirmação
    - Dispensa imediata em caso de sucesso
    - Tratamento de erro em caso de falha
 
 POR QUE ESTE DESIGN?
 - Familiar: Mesmo layout que AddExpenseView
 - Informativo: Mostra quando a despesa foi criada/atualizada
 - Seguro: Confirmação antes de excluir
 - Eficiente: Salva apenas se alterações foram feitas
 - Consistente: Mesmas regras de validação
 
 DETECÇÃO DE ALTERAÇÕES:
 - Compara valores atuais do formulário com a despesa original
 - Verifica categoria, mês, valor e descrição
 - Usa pequeno epsilon (0.001) para comparação de valor
 - Remove espaços em branco da descrição antes de comparar
 
 EXIBIÇÃO DE METADADOS:
 - Sempre mostra data/hora de criação
 - Mostra data/hora de atualização se diferente da criação
 - Formatado em português brasileiro
 - Informação somente leitura
 */

// Feito com Bob