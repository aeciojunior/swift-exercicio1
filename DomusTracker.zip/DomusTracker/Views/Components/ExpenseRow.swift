//
//  ExpenseRow.swift
//  DomusTracker
//
//  Propósito: Um componente de linha reutilizável para exibir informações de despesas
//  Este componente mostra detalhes de despesas em um formato consistente e atraente
//

import SwiftUI

/// ExpenseRow exibe uma única despesa em uma lista
/// Mostra o ícone da categoria, nome, descrição e valor
struct ExpenseRow: View {
    
    // MARK: - Propriedades
    
    /// A despesa a ser exibida
    let expense: Expense
    
    /// Estilo opcional para a linha
    var style: ExpenseRowStyle = .standard
    
    // MARK: - Corpo
    
    var body: some View {
        HStack(spacing: 12) {
            // Ícone da categoria
            categoryIcon
            
            // Detalhes da despesa
            VStack(alignment: .leading, spacing: 4) {
                // Nome da categoria
                Text(expense.categoryEnum?.displayName ?? "Sem categoria")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                // Descrição ou data
                if style == .withDescription {
                    if expense.hasDescription {
                        Text(expense.displayDescription)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                } else {
                    Text(expense.formattedCreatedDate)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Valor
            Text(expense.formattedAmount)
                .font(.headline)
                .foregroundColor(.primary)
                .fontWeight(.semibold)
        }
        .padding(.vertical, 8)
    }
    
    // MARK: - Subvisualizações
    
    /// Ícone da categoria com fundo
    private var categoryIcon: some View {
        ZStack {
            Circle()
                .fill(expense.categoryEnum?.color.opacity(0.2) ?? Color.gray.opacity(0.2))
                .frame(width: 44, height: 44)
            
            Image(systemName: expense.categoryEnum?.icon ?? "questionmark")
                .font(.title3)
                .foregroundColor(expense.categoryEnum?.color ?? .gray)
        }
    }
}

// MARK: - Estilos de Linha

/// Opções de estilo para ExpenseRow
enum ExpenseRowStyle {
    case standard           // Mostra data
    case withDescription    // Mostra descrição se disponível
    case compact            // Menor, mais compacto
}

// MARK: - Linha Compacta

/// ExpenseRowCompact é uma versão mais compacta de ExpenseRow
/// Útil para mostrar mais despesas em menos espaço
struct ExpenseRowCompact: View {
    
    // MARK: - Propriedades
    
    let expense: Expense
    
    // MARK: - Corpo
    
    var body: some View {
        HStack(spacing: 10) {
            // Ícone da categoria (menor)
            Image(systemName: expense.categoryEnum?.icon ?? "questionmark")
                .font(.body)
                .foregroundColor(expense.categoryEnum?.color ?? .gray)
                .frame(width: 32, height: 32)
                .background(
                    Circle()
                        .fill(expense.categoryEnum?.color.opacity(0.2) ?? Color.gray.opacity(0.2))
                )
            
            // Nome da categoria
            Text(expense.categoryEnum?.displayName ?? "Sem categoria")
                .font(.subheadline)
                .foregroundColor(.primary)
            
            Spacer()
            
            // Valor
            Text(expense.formattedAmount)
                .font(.subheadline)
                .foregroundColor(.primary)
                .fontWeight(.medium)
        }
        .padding(.vertical, 6)
    }
}

// MARK: - Linha Detalhada

/// ExpenseRowDetailed mostra mais informações sobre uma despesa
/// Útil para visualizações de detalhes ou quando mais contexto é necessário
struct ExpenseRowDetailed: View {
    
    // MARK: - Propriedades
    
    let expense: Expense
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(spacing: 12) {
            // Linha superior: Categoria e valor
            HStack {
                // Categoria com ícone
                HStack(spacing: 8) {
                    Image(systemName: expense.categoryEnum?.icon ?? "questionmark")
                        .font(.title2)
                        .foregroundColor(expense.categoryEnum?.color ?? .gray)
                    
                    Text(expense.categoryEnum?.displayName ?? "Sem categoria")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                }
                
                Spacer()
                
                // Valor
                Text(expense.formattedAmount)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
            }
            
            // Divisor
            Divider()
            
            // Seção de detalhes
            VStack(alignment: .leading, spacing: 8) {
                // Mês
                DetailRow(
                    icon: "calendar",
                    label: "Mês",
                    value: expense.monthEnum?.displayName ?? "Sem mês"
                )
                
                // Descrição
                if expense.hasDescription {
                    DetailRow(
                        icon: "text.alignleft",
                        label: "Descrição",
                        value: expense.displayDescription
                    )
                }
                
                // Data de criação
                DetailRow(
                    icon: "clock",
                    label: "Criado em",
                    value: expense.formattedCreatedDateTime
                )
                
                // Data de atualização (se diferente da criação)
                if let updatedAt = expense.updatedAt,
                   let createdAt = expense.createdAt,
                   !Calendar.current.isDate(updatedAt, inSameDayAs: createdAt) {
                    DetailRow(
                        icon: "arrow.clockwise",
                        label: "Atualizado em",
                        value: expense.formattedUpdatedDateTime
                    )
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemBackground))
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        )
    }
}

/// DetailRow exibe uma única linha de detalhe com ícone, rótulo e valor
struct DetailRow: View {
    let icon: String
    let label: String
    let value: String
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(width: 20)
            
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.caption)
                .foregroundColor(.primary)
        }
    }
}

// MARK: - Linha Estilo Cartão

/// ExpenseRowCard exibe uma despesa em formato de cartão
/// Útil para layouts de grade ou despesas em destaque
struct ExpenseRowCard: View {
    
    // MARK: - Propriedades
    
    let expense: Expense
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Ícone e nome da categoria
            HStack {
                Image(systemName: expense.categoryEnum?.icon ?? "questionmark")
                    .font(.title2)
                    .foregroundColor(expense.categoryEnum?.color ?? .gray)
                
                Text(expense.categoryEnum?.displayName ?? "Sem categoria")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            
            // Valor
            Text(expense.formattedAmount)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            // Data
            Text(expense.formattedCreatedDate)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(expense.categoryEnum?.color.opacity(0.1) ?? Color.gray.opacity(0.1))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(expense.categoryEnum?.color.opacity(0.3) ?? Color.gray.opacity(0.3), lineWidth: 1)
        )
    }
}

// MARK: - Pré-visualizações

#if DEBUG
struct ExpenseRow_Previews: PreviewProvider {
    static var previews: some View {
        let context = PersistenceController.preview.container.viewContext
        let expense = Expense.create(
            in: context,
            category: .energia,
            month: .janeiro,
            amount: 150.50,
            description: "Conta de luz do mês de janeiro"
        )
        
        Group {
            // Linha padrão
            List {
                ExpenseRow(expense: expense)
                ExpenseRow(expense: expense, style: .withDescription)
            }
            .previewDisplayName("Standard Rows")
            
            // Linha compacta
            List {
                ExpenseRowCompact(expense: expense)
                ExpenseRowCompact(expense: expense)
                ExpenseRowCompact(expense: expense)
            }
            .previewDisplayName("Compact Rows")
            
            // Linha detalhada
            ScrollView {
                ExpenseRowDetailed(expense: expense)
                    .padding()
            }
            .previewDisplayName("Detailed Row")
            
            // Linha de cartão
            ScrollView {
                VStack(spacing: 16) {
                    ExpenseRowCard(expense: expense)
                    ExpenseRowCard(expense: expense)
                }
                .padding()
            }
            .previewDisplayName("Card Rows")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES DE USO DESTE COMPONENTE:
 
 1. Uso básico em uma List:
    List(expenses) { expense in
        ExpenseRow(expense: expense)
    }
 
 2. Com estilo de descrição:
    List(expenses) { expense in
        ExpenseRow(expense: expense, style: .withDescription)
    }
 
 3. Estilo compacto para mais itens:
    List(expenses) { expense in
        ExpenseRowCompact(expense: expense)
    }
 
 4. Visualização detalhada:
    ExpenseRowDetailed(expense: expense)
 
 5. Layout de cartão em uma grade:
    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
        ForEach(expenses) { expense in
            ExpenseRowCard(expense: expense)
        }
    }
 
 6. Com navegação:
    List(expenses) { expense in
        NavigationLink(destination: ExpenseDetailView(expense: expense)) {
            ExpenseRow(expense: expense)
        }
    }
 
 7. Com ações de deslizar:
    List(expenses) { expense in
        ExpenseRow(expense: expense)
            .swipeActions {
                Button(role: .destructive) {
                    deleteExpense(expense)
                } label: {
                    Label("Excluir", systemImage: "trash")
                }
            }
    }
 
 POR QUE MÚLTIPLOS ESTILOS DE LINHA?
 - Padrão: Bom para a maioria das visualizações de lista
 - Compacto: Mostra mais itens em menos espaço
 - Detalhado: Mostra todas as informações de uma vez
 - Cartão: Visual, bom para grades ou itens em destaque
 
 QUANDO USAR CADA ESTILO:
 - ExpenseRow: Visualização de lista padrão
 - ExpenseRowCompact: Listas longas, telas de visão geral
 - ExpenseRowDetailed: Visualizações de detalhes, exibição de despesa única
 - ExpenseRowCard: Layouts de grade, painel, destaques
 */

// Feito com Bob