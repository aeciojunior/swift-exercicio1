//
//  MonthPicker.swift
//  DomusTracker
//
//  Propósito: Um componente seletor reutilizável para selecionar meses de despesas
//  Este componente exibe todos os meses disponíveis de forma amigável ao usuário
//

import SwiftUI

/// MonthPicker fornece uma maneira amigável de selecionar um mês de despesa
/// Exibe meses em português com várias opções de layout
struct MonthPicker: View {
    
    // MARK: - Propriedades
    
    /// O mês atualmente selecionado
    /// Este é um binding para que as alterações sejam refletidas na visualização pai
    @Binding var selectedMonth: ExpenseMonth
    
    /// Título opcional para o seletor
    /// Se nil, nenhum título é exibido
    var title: String?
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Exibe título se fornecido
            if let title = title {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
            }
            
            // O seletor em si
            Picker("Mês", selection: $selectedMonth) {
                // Percorre todos os meses disponíveis
                ForEach(ExpenseMonth.allCases) { month in
                    Text(month.displayName)
                        .tag(month)
                }
            }
            .pickerStyle(.menu) // Usa estilo de menu para aparência de dropdown
        }
    }
}

// MARK: - Seletor de Rolagem Horizontal

/// MonthPickerHorizontal exibe meses em uma lista rolável horizontal
/// Isso é útil para uma experiência de seleção de mês mais visual
struct MonthPickerHorizontal: View {
    
    // MARK: - Propriedades
    
    @Binding var selectedMonth: ExpenseMonth
    var title: String?
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Exibe título se fornecido
            if let title = title {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .padding(.horizontal)
            }
            
            // Lista rolável horizontal de meses
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(ExpenseMonth.allCases) { month in
                        MonthButton(
                            month: month,
                            isSelected: selectedMonth == month
                        ) {
                            // Atualiza seleção quando tocado
                            withAnimation(.spring(response: 0.3)) {
                                selectedMonth = month
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

/// MonthButton é um único botão para um mês
/// Usado no seletor de rolagem horizontal
struct MonthButton: View {
    
    // MARK: - Propriedades
    
    let month: ExpenseMonth
    let isSelected: Bool
    let action: () -> Void
    
    // MARK: - Corpo
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                // Abreviação do mês
                Text(month.abbreviation)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(isSelected ? .white : .secondary)
                
                // Número do mês
                Text("\(month.number)")
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(isSelected ? .white : .primary)
            }
            .frame(width: 60, height: 60)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isSelected ? Color.accentColor : Color(.systemGray6))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? Color.accentColor : Color.clear, lineWidth: 2)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Estilo de Controle Segmentado

/// MonthPickerSegmented exibe meses em um estilo de controle segmentado
/// Melhor para mostrar um número limitado de meses (ex: primeiros 5 meses)
struct MonthPickerSegmented: View {
    
    // MARK: - Propriedades
    
    @Binding var selectedMonth: ExpenseMonth
    var months: [ExpenseMonth] = ExpenseMonth.allCases
    var title: String?
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Exibe título se fornecido
            if let title = title {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
            }
            
            // Controle segmentado
            Picker("Mês", selection: $selectedMonth) {
                ForEach(months) { month in
                    Text(month.abbreviation)
                        .tag(month)
                }
            }
            .pickerStyle(.segmented)
        }
    }
}

// MARK: - Rótulo de Mês

/// MonthLabel exibe um mês de forma compacta
/// Útil para mostrar o mês selecionado
struct MonthLabel: View {
    
    // MARK: - Propriedades
    
    let month: ExpenseMonth
    var style: MonthLabelStyle = .full
    
    // MARK: - Corpo
    
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "calendar")
                .font(.body)
                .foregroundColor(.accentColor)
            
            Text(displayText)
                .font(.body)
                .foregroundColor(.primary)
        }
    }
    
    // MARK: - Propriedades Computadas
    
    private var displayText: String {
        switch style {
        case .full:
            return month.displayName
        case .abbreviated:
            return month.abbreviation
        case .withNumber:
            return "\(month.displayName) (\(month.number))"
        }
    }
}

/// Opções de estilo para MonthLabel
enum MonthLabelStyle {
    case full           // "Janeiro"
    case abbreviated    // "Jan"
    case withNumber     // "Janeiro (1)"
}

// MARK: - Navegação de Mês

/// MonthNavigator fornece navegação anterior/próximo entre meses
/// Útil para navegar despesas mês a mês
struct MonthNavigator: View {
    
    // MARK: - Propriedades
    
    @Binding var selectedMonth: ExpenseMonth
    
    // MARK: - Corpo
    
    var body: some View {
        HStack {
            // Botão de mês anterior
            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    selectedMonth = selectedMonth.previous
                }
            }) {
                Image(systemName: "chevron.left")
                    .font(.title3)
                    .foregroundColor(.accentColor)
                    .frame(width: 44, height: 44)
            }
            
            Spacer()
            
            // Exibição do mês atual
            Text(selectedMonth.displayName)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            Spacer()
            
            // Botão de próximo mês
            Button(action: {
                withAnimation(.spring(response: 0.3)) {
                    selectedMonth = selectedMonth.next
                }
            }) {
                Image(systemName: "chevron.right")
                    .font(.title3)
                    .foregroundColor(.accentColor)
                    .frame(width: 44, height: 44)
            }
        }
        .padding(.horizontal)
    }
}

// MARK: - Pré-visualizações

#if DEBUG
struct MonthPicker_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Pré-visualização do seletor padrão
            MonthPicker(
                selectedMonth: .constant(.janeiro),
                title: "Selecione o Mês"
            )
            .padding()
            .previewDisplayName("Standard Picker")
            
            // Pré-visualização do seletor horizontal
            MonthPickerHorizontal(
                selectedMonth: .constant(.maio),
                title: "Selecione o Mês"
            )
            .previewDisplayName("Horizontal Picker")
            
            // Pré-visualização do seletor segmentado (primeiros 5 meses)
            MonthPickerSegmented(
                selectedMonth: .constant(.marco),
                months: [.janeiro, .fevereiro, .marco, .abril, .maio],
                title: "Selecione o Mês"
            )
            .padding()
            .previewDisplayName("Segmented Picker")
            
            // Pré-visualização dos rótulos de mês
            VStack(spacing: 16) {
                MonthLabel(month: .janeiro, style: .full)
                MonthLabel(month: .fevereiro, style: .abbreviated)
                MonthLabel(month: .marco, style: .withNumber)
            }
            .padding()
            .previewDisplayName("Month Labels")
            
            // Pré-visualização do navegador de mês
            MonthNavigator(selectedMonth: .constant(.maio))
                .padding()
                .previewDisplayName("Month Navigator")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES DE USO DESTE COMPONENTE:
 
 1. Uso básico com seletor padrão:
    @State private var selectedMonth: ExpenseMonth = .janeiro
    
    MonthPicker(
        selectedMonth: $selectedMonth,
        title: "Mês"
    )
 
 2. Usando o seletor de rolagem horizontal:
    @State private var selectedMonth: ExpenseMonth = .janeiro
    
    MonthPickerHorizontal(
        selectedMonth: $selectedMonth,
        title: "Selecione o Mês"
    )
 
 3. Usando o controle segmentado (para meses limitados):
    @State private var selectedMonth: ExpenseMonth = .janeiro
    
    MonthPickerSegmented(
        selectedMonth: $selectedMonth,
        months: [.janeiro, .fevereiro, .marco, .abril, .maio],
        title: "Mês"
    )
 
 4. Exibindo um rótulo de mês:
    MonthLabel(month: .janeiro)
    MonthLabel(month: .janeiro, style: .abbreviated)
    MonthLabel(month: .janeiro, style: .withNumber)
 
 5. Usando o navegador de mês:
    @State private var selectedMonth: ExpenseMonth = .janeiro
    
    MonthNavigator(selectedMonth: $selectedMonth)
 
 POR QUE MÚLTIPLOS ESTILOS DE SELETOR?
 - Padrão: Compacto, bom para formulários
 - Horizontal: Visual, bom para navegação
 - Segmentado: Bom para opções limitadas
 - Navegador: Bom para navegação sequencial
 
 QUANDO USAR CADA ESTILO:
 - MonthPicker: Formulários, configurações, espaços compactos
 - MonthPickerHorizontal: Navegação principal, seleção visual
 - MonthPickerSegmented: Quando mostrar apenas alguns meses
 - MonthNavigator: Quando usuários navegam mês a mês
 - MonthLabel: Somente exibição, mostrando seleção atual
 */

// Feito com Bob