//
//  CategoryPicker.swift
//  DomusTracker
//
//  Propósito: Um componente seletor reutilizável para selecionar categorias de despesas
//  Este componente exibe todas as categorias disponíveis com seus ícones e cores
//

import SwiftUI

/// CategoryPicker fornece uma maneira amigável de selecionar uma categoria de despesa
/// Exibe cada categoria com seu ícone, nome e cor
struct CategoryPicker: View {
    
    // MARK: - Propriedades
    
    /// A categoria atualmente selecionada
    /// Este é um binding para que as alterações sejam refletidas na visualização pai
    @Binding var selectedCategory: ExpenseCategory
    
    /// Título opcional para o seletor
    /// Se nil, nenhum título é exibido
    var title: String?
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Exibe título se fornecido
            if let title = title {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
            }
            
            // O seletor em si
            Picker("Categoria", selection: $selectedCategory) {
                // Percorre todas as categorias disponíveis
                ForEach(ExpenseCategory.allCases) { category in
                    // Exibe cada categoria com seu ícone e nome
                    Label {
                        Text(category.displayName)
                    } icon: {
                        Image(systemName: category.icon)
                            .foregroundColor(category.color)
                    }
                    .tag(category)
                }
            }
            .pickerStyle(.menu) // Usa estilo de menu para aparência de dropdown
        }
    }
}

// MARK: - Estilos Alternativos

/// CategoryPickerGrid exibe categorias em um layout de grade
/// Isso é útil quando você quer mostrar todas as categorias de uma vez
struct CategoryPickerGrid: View {
    
    // MARK: - Propriedades
    
    @Binding var selectedCategory: ExpenseCategory
    var title: String?
    
    /// Configuração do layout de grade
    /// Cria 4 colunas com largura flexível
    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Exibe título se fornecido
            if let title = title {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
            }
            
            // Grade de botões de categoria
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(ExpenseCategory.allCases) { category in
                    CategoryButton(
                        category: category,
                        isSelected: selectedCategory == category
                    ) {
                        // Atualiza seleção quando tocado
                        selectedCategory = category
                    }
                }
            }
        }
    }
}

/// CategoryButton é um único botão para uma categoria
/// Usado no layout de grade
struct CategoryButton: View {
    
    // MARK: - Propriedades
    
    let category: ExpenseCategory
    let isSelected: Bool
    let action: () -> Void
    
    // MARK: - Corpo
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                // Ícone da categoria
                Image(systemName: category.icon)
                    .font(.title2)
                    .foregroundColor(isSelected ? .white : category.color)
                
                // Nome da categoria
                Text(category.displayName)
                    .font(.caption)
                    .foregroundColor(isSelected ? .white : .primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isSelected ? category.color : Color(.systemGray6))
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Exibição de Categoria Inline

/// CategoryLabel exibe uma categoria com seu ícone
/// Útil para mostrar a categoria selecionada de forma compacta
struct CategoryLabel: View {
    
    // MARK: - Propriedades
    
    let category: ExpenseCategory
    var showName: Bool = true
    var iconSize: Font = .body
    
    // MARK: - Corpo
    
    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: category.icon)
                .font(iconSize)
                .foregroundColor(category.color)
            
            if showName {
                Text(category.displayName)
                    .font(.body)
                    .foregroundColor(.primary)
            }
        }
    }
}

// MARK: - Pré-visualizações

#if DEBUG
struct CategoryPicker_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Pré-visualização do seletor padrão
            CategoryPicker(
                selectedCategory: .constant(.energia),
                title: "Selecione a Categoria"
            )
            .padding()
            .previewDisplayName("Standard Picker")
            
            // Pré-visualização do seletor de grade
            CategoryPickerGrid(
                selectedCategory: .constant(.energia),
                title: "Selecione a Categoria"
            )
            .padding()
            .previewDisplayName("Grid Picker")
            
            // Pré-visualização do rótulo de categoria
            VStack(spacing: 16) {
                CategoryLabel(category: .energia)
                CategoryLabel(category: .internet)
                CategoryLabel(category: .agua)
            }
            .padding()
            .previewDisplayName("Category Labels")
            
            // Pré-visualização de todos os botões de categoria
            ScrollView {
                CategoryPickerGrid(
                    selectedCategory: .constant(.energia),
                    title: "Todas as Categorias"
                )
                .padding()
            }
            .previewDisplayName("All Categories")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES DE USO DESTE COMPONENTE:
 
 1. Uso básico com seletor padrão:
    @State private var selectedCategory: ExpenseCategory = .energia
    
    CategoryPicker(
        selectedCategory: $selectedCategory,
        title: "Categoria"
    )
 
 2. Usando o layout de grade:
    @State private var selectedCategory: ExpenseCategory = .energia
    
    CategoryPickerGrid(
        selectedCategory: $selectedCategory,
        title: "Selecione a Categoria"
    )
 
 3. Exibindo um rótulo de categoria:
    CategoryLabel(category: .energia)
 
 4. Exibindo apenas o ícone:
    CategoryLabel(category: .energia, showName: false)
 
 5. Tamanho de ícone personalizado:
    CategoryLabel(
        category: .energia,
        iconSize: .title
    )
 
 POR QUE USAR COMPONENTES REUTILIZÁVEIS?
 - Consistência: Mesma aparência em todo o aplicativo
 - Manutenibilidade: Altere o design em um único lugar
 - Reutilização: Use o mesmo componente em múltiplas visualizações
 - Testabilidade: Mais fácil testar componentes individuais
 - Flexibilidade: Múltiplos estilos para diferentes casos de uso
 
 VARIAÇÕES DO COMPONENTE:
 - CategoryPicker: Seletor dropdown padrão (compacto)
 - CategoryPickerGrid: Layout de grade (mostra todas as opções)
 - CategoryButton: Botão de categoria individual
 - CategoryLabel: Rótulo de categoria somente exibição
 */

// Feito com Bob