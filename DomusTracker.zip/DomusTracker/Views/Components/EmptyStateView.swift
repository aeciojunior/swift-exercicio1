//
//  EmptyStateView.swift
//  DomusTracker
//
//  Propósito: Um componente reutilizável para exibir estados vazios
//  Este componente mostra uma mensagem amigável quando não há dados para exibir
//

import SwiftUI

/// EmptyStateView exibe uma mensagem quando não há conteúdo para mostrar
/// Fornece uma maneira consistente e amigável de lidar com estados vazios
struct EmptyStateView: View {
    
    // MARK: - Propriedades
    
    /// O ícone SF Symbol a ser exibido
    var icon: String
    
    /// A mensagem de título principal
    var title: String
    
    /// Subtítulo opcional com mais detalhes
    var subtitle: String?
    
    /// Botão de ação opcional
    var actionTitle: String?
    var action: (() -> Void)?
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(spacing: 20) {
            // Ícone
            Image(systemName: icon)
                .font(.system(size: 60))
                .foregroundColor(.secondary)
            
            // Título
            Text(title)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
            
            // Subtítulo
            if let subtitle = subtitle {
                Text(subtitle)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
            
            // Botão de ação
            if let actionTitle = actionTitle, let action = action {
                Button(action: action) {
                    Text(actionTitle)
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.accentColor)
                        )
                }
                .padding(.top, 8)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

// MARK: - Estados Vazios Predefinidos

extension EmptyStateView {
    
    /// Estado vazio para quando não há despesas
    static func noExpenses(action: (() -> Void)? = nil) -> EmptyStateView {
        EmptyStateView(
            icon: "tray",
            title: "Nenhuma despesa encontrada",
            subtitle: "Adicione sua primeira despesa para começar a acompanhar seus gastos.",
            actionTitle: action != nil ? "Adicionar Despesa" : nil,
            action: action
        )
    }
    
    /// Estado vazio para quando não há despesas em um mês específico
    static func noExpensesInMonth(_ month: ExpenseMonth, action: (() -> Void)? = nil) -> EmptyStateView {
        EmptyStateView(
            icon: "calendar.badge.exclamationmark",
            title: "Nenhuma despesa em \(month.displayName)",
            subtitle: "Você ainda não registrou despesas para este mês.",
            actionTitle: action != nil ? "Adicionar Despesa" : nil,
            action: action
        )
    }
    
    /// Estado vazio para quando não há despesas em uma categoria específica
    static func noExpensesInCategory(_ category: ExpenseCategory, action: (() -> Void)? = nil) -> EmptyStateView {
        EmptyStateView(
            icon: category.icon,
            title: "Nenhuma despesa de \(category.displayName)",
            subtitle: "Você ainda não registrou despesas nesta categoria.",
            actionTitle: action != nil ? "Adicionar Despesa" : nil,
            action: action
        )
    }
    
    /// Estado vazio para resultados de pesquisa
    static func noSearchResults(searchText: String) -> EmptyStateView {
        EmptyStateView(
            icon: "magnifyingglass",
            title: "Nenhum resultado encontrado",
            subtitle: "Não encontramos despesas correspondentes a \"\(searchText)\".",
            actionTitle: nil,
            action: nil
        )
    }
    
    /// Estado vazio para quando os dados estão carregando
    static func loading() -> EmptyStateView {
        EmptyStateView(
            icon: "arrow.clockwise",
            title: "Carregando...",
            subtitle: "Aguarde enquanto carregamos suas despesas.",
            actionTitle: nil,
            action: nil
        )
    }
    
    /// Estado vazio para erros
    static func error(message: String? = nil, retry: (() -> Void)? = nil) -> EmptyStateView {
        EmptyStateView(
            icon: "exclamationmark.triangle",
            title: "Algo deu errado",
            subtitle: message ?? "Ocorreu um erro ao carregar os dados. Tente novamente.",
            actionTitle: retry != nil ? "Tentar Novamente" : nil,
            action: retry
        )
    }
}

// MARK: - Estado Vazio Animado

/// AnimatedEmptyStateView adiciona uma animação sutil ao estado vazio
/// Isso faz a interface parecer mais viva e responsiva
struct AnimatedEmptyStateView: View {
    
    // MARK: - Propriedades
    
    var icon: String
    var title: String
    var subtitle: String?
    var actionTitle: String?
    var action: (() -> Void)?
    
    @State private var isAnimating = false
    
    // MARK: - Corpo
    
    var body: some View {
        VStack(spacing: 20) {
            // Ícone animado
            Image(systemName: icon)
                .font(.system(size: 60))
                .foregroundColor(.secondary)
                .scaleEffect(isAnimating ? 1.1 : 1.0)
                .animation(
                    Animation.easeInOut(duration: 1.5)
                        .repeatForever(autoreverses: true),
                    value: isAnimating
                )
            
            // Título
            Text(title)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
            
            // Subtítulo
            if let subtitle = subtitle {
                Text(subtitle)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
            
            // Botão de ação
            if let actionTitle = actionTitle, let action = action {
                Button(action: action) {
                    Text(actionTitle)
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.accentColor)
                        )
                }
                .padding(.top, 8)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
        .onAppear {
            isAnimating = true
        }
    }
}

// MARK: - Estado Vazio Compacto

/// CompactEmptyStateView é uma versão menor para uso inline
/// Útil para seções ou áreas menores
struct CompactEmptyStateView: View {
    
    // MARK: - Propriedades
    
    var icon: String
    var message: String
    
    // MARK: - Corpo
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(.secondary)
            
            Text(message)
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(.systemGray6))
        )
    }
}

// MARK: - Pré-visualizações

#if DEBUG
struct EmptyStateView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Sem despesas
            EmptyStateView.noExpenses(action: {
                print("Add expense tapped")
            })
            .previewDisplayName("No Expenses")
            
            // Sem despesas no mês
            EmptyStateView.noExpensesInMonth(.janeiro, action: {
                print("Add expense tapped")
            })
            .previewDisplayName("No Expenses in Month")
            
            // Sem despesas na categoria
            EmptyStateView.noExpensesInCategory(.energia, action: {
                print("Add expense tapped")
            })
            .previewDisplayName("No Expenses in Category")
            
            // Sem resultados de pesquisa
            EmptyStateView.noSearchResults(searchText: "internet")
                .previewDisplayName("No Search Results")
            
            // Carregando
            EmptyStateView.loading()
                .previewDisplayName("Loading")
            
            // Erro
            EmptyStateView.error(retry: {
                print("Retry tapped")
            })
            .previewDisplayName("Error")
            
            // Animado
            AnimatedEmptyStateView(
                icon: "tray",
                title: "Nenhuma despesa",
                subtitle: "Adicione sua primeira despesa",
                actionTitle: "Adicionar",
                action: { print("Add tapped") }
            )
            .previewDisplayName("Animated")
            
            // Compacto
            VStack {
                CompactEmptyStateView(
                    icon: "tray",
                    message: "Nenhuma despesa encontrada"
                )
                .padding()
                
                Spacer()
            }
            .previewDisplayName("Compact")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES DE USO DESTE COMPONENTE:
 
 1. Uso básico:
    EmptyStateView(
        icon: "tray",
        title: "Nenhuma despesa",
        subtitle: "Adicione sua primeira despesa"
    )
 
 2. Com botão de ação:
    EmptyStateView(
        icon: "tray",
        title: "Nenhuma despesa",
        subtitle: "Adicione sua primeira despesa",
        actionTitle: "Adicionar Despesa",
        action: { showAddExpense = true }
    )
 
 3. Usando estados vazios predefinidos:
    EmptyStateView.noExpenses(action: { showAddExpense = true })
    EmptyStateView.noExpensesInMonth(.janeiro)
    EmptyStateView.noSearchResults(searchText: "internet")
    EmptyStateView.error(retry: { loadData() })
 
 4. Versão animada:
    AnimatedEmptyStateView(
        icon: "tray",
        title: "Nenhuma despesa",
        subtitle: "Adicione sua primeira despesa"
    )
 
 5. Versão compacta para uso inline:
    CompactEmptyStateView(
        icon: "tray",
        message: "Nenhuma despesa encontrada"
    )
 
 6. Exibição condicional:
    if expenses.isEmpty {
        EmptyStateView.noExpenses(action: { showAddExpense = true })
    } else {
        List(expenses) { expense in
            ExpenseRow(expense: expense)
        }
    }
 
 POR QUE USAR VISUALIZAÇÕES DE ESTADO VAZIO?
 - Experiência do Usuário: Informa aos usuários por que não veem nada
 - Orientação: Sugere o que fazer a seguir
 - Consistência: Mesma aparência em todo o aplicativo
 - Profissionalismo: Mostra atenção aos detalhes
 - Reduz confusão: Comunicação clara
 
 QUANDO USAR CADA VARIANTE:
 - EmptyStateView: Estados vazios de tela cheia
 - AnimatedEmptyStateView: Quando você quer animação sutil
 - CompactEmptyStateView: Inline, dentro de seções
 - Estados predefinidos: Cenários comuns (sem dados, erros, etc.)
 */

// Feito com Bob