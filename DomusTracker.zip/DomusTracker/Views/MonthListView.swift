//
//  MonthListView.swift
//  DomusTracker
//
//  Propósito: Exibe uma lista de todos os meses com seus totais de despesas
//  Usuários podem tocar em um mês para ver despesas detalhadas daquele mês
//

import SwiftUI
import CoreData

/// MonthListView mostra todos os meses disponíveis com seus totais de despesas
/// Isso fornece uma visão geral dos gastos em diferentes meses
struct MonthListView: View {
    
    // MARK: - Ambiente
    
    /// Contexto de objeto gerenciado do Core Data
    @Environment(\.managedObjectContext) private var viewContext
    
    // MARK: - Estado
    
    /// ViewModel para gerenciar operações de despesas
    @StateObject private var viewModel: ExpenseViewModel
    
    /// Busca todas as despesas para calcular totais
    /// Buscamos todas as despesas e as agrupamos por mês na visualização
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)],
        animation: .default)
    private var expenses: FetchedResults<Expense>
    
    // MARK: - Inicialização
    
    init() {
        // Inicializa o ViewModel com o contexto
        // Usamos @StateObject para garantir que o ViewModel persista entre atualizações da visualização
        let context = PersistenceController.shared.container.viewContext
        _viewModel = StateObject(wrappedValue: ExpenseViewModel(context: context))
    }
    
    // MARK: - Corpo
    
    var body: some View {
        List {
            // Seção de cabeçalho com total
            Section {
                totalCard
            }
            
            // Seção de meses
            Section(header: Text("Meses")) {
                ForEach(ExpenseMonth.allCases) { month in
                    NavigationLink(destination: ExpenseListView(selectedMonth: month)) {
                        MonthRow(
                            month: month,
                            total: viewModel.totalForMonth(month),
                            expenseCount: viewModel.expenseCountForMonth(month)
                        )
                    }
                }
            }
        }
        .navigationTitle("DomusTracker")
        .navigationBarTitleDisplayMode(.large)
    }
    
    // MARK: - Subvisualizações
    
    /// Cartão mostrando o total geral de todas as despesas
    private var totalCard: some View {
        VStack(spacing: 12) {
            // Título
            Text("Total Geral")
                .font(.headline)
                .foregroundColor(.secondary)
            
            // Valor
            Text(viewModel.formatCurrency(viewModel.grandTotal()))
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
            
            // Contagem de despesas
            Text("\(expenses.count) despesa(s) registrada(s)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.accentColor.opacity(0.1))
        )
    }
}

// MARK: - Linha de Mês

/// MonthRow exibe um único mês com seu total e contagem de despesas
struct MonthRow: View {
    
    // MARK: - Propriedades
    
    let month: ExpenseMonth
    let total: Double
    let expenseCount: Int
    
    // MARK: - Corpo
    
    var body: some View {
        HStack(spacing: 12) {
            // Ícone e número do mês
            VStack(spacing: 4) {
                Text(month.abbreviation)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                Text("\(month.number)")
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(.accentColor)
            }
            .frame(width: 50)
            
            // Nome do mês e contagem
            VStack(alignment: .leading, spacing: 4) {
                Text(month.displayName)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text("\(expenseCount) despesa(s)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Valor total
            VStack(alignment: .trailing, spacing: 4) {
                Text(total.asCurrency)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .fontWeight(.semibold)
                
                // Indicador visual se houver despesas
                if expenseCount > 0 {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 8, height: 8)
                }
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Layout Alternativo

/// MonthListViewGrid exibe meses em um layout de grade
/// Este é um layout alternativo que pode ser usado em vez da lista
struct MonthListViewGrid: View {
    
    // MARK: - Ambiente
    
    @Environment(\.managedObjectContext) private var viewContext
    
    // MARK: - Estado
    
    @StateObject private var viewModel: ExpenseViewModel
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)],
        animation: .default)
    private var expenses: FetchedResults<Expense>
    
    /// Configuração do layout de grade
    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    // MARK: - Inicialização
    
    init() {
        let context = PersistenceController.shared.container.viewContext
        _viewModel = StateObject(wrappedValue: ExpenseViewModel(context: context))
    }
    
    // MARK: - Corpo
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Cartão de total
                totalCard
                    .padding(.horizontal)
                
                // Grade de meses
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(ExpenseMonth.allCases) { month in
                        NavigationLink(destination: ExpenseListView(selectedMonth: month)) {
                            MonthCard(
                                month: month,
                                total: viewModel.totalForMonth(month),
                                expenseCount: viewModel.expenseCountForMonth(month)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        .navigationTitle("DomusTracker")
        .navigationBarTitleDisplayMode(.large)
    }
    
    // MARK: - Subvisualizações
    
    private var totalCard: some View {
        VStack(spacing: 12) {
            Text("Total Geral")
                .font(.headline)
                .foregroundColor(.secondary)
            
            Text(viewModel.formatCurrency(viewModel.grandTotal()))
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
            
            Text("\(expenses.count) despesa(s) registrada(s)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.accentColor.opacity(0.1))
        )
    }
}

/// MonthCard exibe um mês em formato de cartão para layout de grade
struct MonthCard: View {
    
    let month: ExpenseMonth
    let total: Double
    let expenseCount: Int
    
    var body: some View {
        VStack(spacing: 12) {
            // Nome do mês
            Text(month.displayName)
                .font(.headline)
                .foregroundColor(.primary)
            
            // Valor total
            Text(total.asCurrency)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(.accentColor)
            
            // Contagem de despesas
            Text("\(expenseCount) despesa(s)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemBackground))
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(expenseCount > 0 ? Color.accentColor.opacity(0.3) : Color.clear, lineWidth: 2)
        )
    }
}

// MARK: - Pré-visualizações

#if DEBUG
struct MonthListView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Layout de lista
            NavigationView {
                MonthListView()
            }
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
            .previewDisplayName("List Layout")
            
            // Layout de grade
            NavigationView {
                MonthListViewGrid()
            }
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
            .previewDisplayName("Grid Layout")
        }
    }
}
#endif

/*
 GUIA PARA INICIANTES DESTA VISUALIZAÇÃO:
 
 1. Propósito:
    - Mostra todos os 12 meses do ano
    - Exibe total de despesas para cada mês
    - Mostra contagem de despesas por mês
    - Fornece navegação para lista detalhada de despesas
 
 2. Fluxo de Dados:
    - @FetchRequest busca todas as despesas do Core Data
    - ViewModel calcula totais por mês
    - Visualização exibe os dados calculados
 
 3. Navegação:
    - Toque em um mês para ver suas despesas
    - NavigationLink passa o mês selecionado para ExpenseListView
 
 4. Recursos Principais:
    - Cartão de total geral no topo
    - Indicadores visuais para meses com despesas
    - Lista limpa e organizada de todos os meses
    - Exibição de moeda formatada
 
 5. Layout Alternativo:
    - MonthListViewGrid fornece um layout de grade
    - Use-o substituindo MonthListView por MonthListViewGrid
    - Layout de grade é mais visual e compacto
 
 6. Personalização:
    - Altere cores modificando .foregroundColor
    - Ajuste espaçamento modificando parâmetros de spacing
    - Altere estilo do cartão modificando modificadores de background
 
 POR QUE ESTE DESIGN?
 - Visão Geral: Veja todos os meses de relance
 - Acesso Rápido: Toque em qualquer mês para ver detalhes
 - Feedback Visual: Ponto verde mostra meses com despesas
 - Contexto: Total no topo fornece visão geral
 - Familiar: Padrão de lista iOS padrão
 
 CÁLCULOS DE DADOS:
 - viewModel.totalForMonth(month): Soma todas as despesas de um mês
 - viewModel.expenseCountForMonth(month): Conta despesas de um mês
 - viewModel.grandTotal(): Soma todas as despesas de todos os meses
 */

// Feito com Bob