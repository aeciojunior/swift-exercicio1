//
//  ContentView.swift
//  DomusTracker
//
//  Propósito: View de navegação principal para o aplicativo
//  Esta é a view raiz que fornece navegação entre diferentes telas
//

import SwiftUI
import CoreData

/// ContentView é o ponto de entrada principal para a UI do aplicativo
/// Fornece uma estrutura de navegação baseada em abas
struct ContentView: View {
    
    // MARK: - Ambiente
    
    /// Contexto de objeto gerenciado do Core Data
    /// Isso é injetado do ponto de entrada do aplicativo
    @Environment(\.managedObjectContext) private var viewContext
    
    // MARK: - Estado
    
    /// Aba atualmente selecionada
    @State private var selectedTab = 0
    
    // MARK: - Corpo
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Aba 1: View de Lista de Meses
            // Mostra todos os meses com seus totais
            NavigationView {
                MonthListView()
            }
            .tabItem {
                Label("Meses", systemImage: "calendar")
            }
            .tag(0)
            
            // Aba 2: View de Todas as Despesas
            // Mostra todas as despesas de todos os meses
            NavigationView {
                ExpenseListView(selectedMonth: nil)
            }
            .tabItem {
                Label("Todas", systemImage: "list.bullet")
            }
            .tag(1)
        }
        .accentColor(.blue) // Define a cor de destaque para o aplicativo
    }
}

// MARK: - Previews

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
#endif

/*
 GUIA PARA INICIANTES SOBRE ESTA VIEW:
 
 1. Estrutura do TabView:
    - TabView fornece abas de navegação na parte inferior
    - Cada aba contém uma NavigationView para navegação hierárquica
    - selectedTab rastreia qual aba está atualmente ativa
 
 2. Ambiente:
    - @Environment(\.managedObjectContext) injeta o contexto do Core Data
    - Isso é configurado no ponto de entrada do aplicativo (DomusTrackerApp.swift)
    - Todas as views filhas herdam este contexto
 
 3. Padrão de Navegação:
    - Aba 1: MonthListView - Navegar despesas por mês
    - Aba 2: ExpenseListView - Ver todas as despesas de uma vez
 
 4. Por que Esta Estrutura?
    - Simples: Fácil de entender e navegar
    - Familiar: Padrão iOS padrão que os usuários conhecem
    - Flexível: Fácil de adicionar mais abas se necessário
    - Limpo: Separa responsabilidades entre views
 
 5. Customização:
    - Mudar ícones das abas modificando systemImage
    - Mudar rótulos das abas modificando o texto
    - Adicionar mais abas adicionando mais blocos .tabItem
    - Mudar cor de destaque para combinar com sua marca
 
 FLUXO DE NAVEGAÇÃO:
 ContentView (Abas)
 ├── MonthListView (Aba 1)
 │   └── ExpenseListView (para mês selecionado)
 │       ├── AddExpenseView (adicionar nova)
 │       └── EditExpenseView (editar existente)
 └── ExpenseListView (Aba 2 - todas as despesas)
     ├── AddExpenseView (adicionar nova)
     └── EditExpenseView (editar existente)
 */

// Feito com Bob