//
//  ExpenseViewModel.swift
//  DomusTracker
//
//  Propósito: Gerencia o estado e a lógica de negócios para operações de despesas
//  Este ViewModel lida com operações CRUD, filtragem e gerenciamento de estado
//  Atua como ponte entre a UI (Views) e a camada de dados (Core Data)
//

import Foundation
import CoreData
import SwiftUI

/// ExpenseViewModel gerencia todas as operações e estado relacionados a despesas
/// É um ObservableObject, o que significa que as views SwiftUI podem observar mudanças
/// e atualizar automaticamente quando os dados mudam
class ExpenseViewModel: ObservableObject {
    
    // MARK: - Propriedades
    
    /// O contexto de objeto gerenciado do Core Data
    /// É aqui que todas as operações de banco de dados acontecem
    private let viewContext: NSManagedObjectContext
    
    /// Mês atualmente selecionado para filtrar despesas
    /// Quando isso muda, as views que observam este ViewModel serão atualizadas
    @Published var selectedMonth: ExpenseMonth?
    
    /// Categoria atualmente selecionada para filtragem (opcional)
    /// Nil significa mostrar todas as categorias
    @Published var selectedCategory: ExpenseCategory?
    
    /// Mensagem de erro para exibir ao usuário
    /// Quando definida, a UI deve mostrar um alerta com esta mensagem
    @Published var errorMessage: String?
    
    /// Mensagem de sucesso para exibir ao usuário
    /// Quando definida, a UI deve mostrar uma notificação de sucesso
    @Published var successMessage: String?
    
    /// Indica se uma operação está em andamento
    /// Use isso para mostrar indicadores de carregamento na UI
    @Published var isLoading: Bool = false
    
    // MARK: - Inicialização
    
    /// Inicializa o ViewModel com um contexto Core Data
    /// - Parameter context: O contexto de objeto gerenciado para usar nas operações de banco de dados
    init(context: NSManagedObjectContext) {
        self.viewContext = context
        // Define o mês atual como padrão
        self.selectedMonth = ExpenseMonth.current
    }
    
    // MARK: - Operações CRUD
    
    /// Cria uma nova despesa no banco de dados
    /// Este método valida a entrada, cria a despesa e a salva
    ///
    /// - Parameters:
    ///   - category: A categoria da despesa
    ///   - month: O mês da despesa
    ///   - amount: O valor da despesa (deve ser positivo)
    ///   - description: Descrição opcional da despesa
    /// - Returns: O objeto Expense criado, ou nil se a criação falhou
    @discardableResult
    func createExpense(
        category: ExpenseCategory,
        month: ExpenseMonth,
        amount: Double,
        description: String?
    ) -> Expense? {
        // Limpa mensagens anteriores
        clearMessages()
        
        // Valida o valor
        guard amount > 0 else {
            errorMessage = "O valor deve ser maior que zero."
            return nil
        }
        
        // Valida o comprimento da descrição se fornecida
        if let desc = description, desc.count > 200 {
            errorMessage = "A descrição não pode ter mais de 200 caracteres."
            return nil
        }
        
        // Cria a despesa usando o método de conveniência
        let expense = Expense.create(
            in: viewContext,
            category: category,
            month: month,
            amount: amount,
            description: description
        )
        
        // Valida a despesa
        do {
            try expense.validate()
        } catch {
            errorMessage = error.localizedDescription
            viewContext.delete(expense) // Remove despesa inválida
            return nil
        }
        
        // Salva no banco de dados
        if saveContext() {
            successMessage = "Despesa criada com sucesso!"
            return expense
        } else {
            viewContext.delete(expense) // Remove se o salvamento falhou
            return nil
        }
    }
    
    /// Atualiza uma despesa existente
    /// Este método valida os novos dados e salva as alterações
    ///
    /// - Parameters:
    ///   - expense: A despesa a ser atualizada
    ///   - category: A nova categoria
    ///   - month: O novo mês
    ///   - amount: O novo valor (deve ser positivo)
    ///   - description: A nova descrição
    /// - Returns: True se a atualização foi bem-sucedida, false caso contrário
    @discardableResult
    func updateExpense(
        _ expense: Expense,
        category: ExpenseCategory,
        month: ExpenseMonth,
        amount: Double,
        description: String?
    ) -> Bool {
        // Limpa mensagens anteriores
        clearMessages()
        
        // Valida o valor
        guard amount > 0 else {
            errorMessage = "O valor deve ser maior que zero."
            return false
        }
        
        // Valida o comprimento da descrição se fornecida
        if let desc = description, desc.count > 200 {
            errorMessage = "A descrição não pode ter mais de 200 caracteres."
            return false
        }
        
        // Atualiza a despesa
        expense.update(
            category: category,
            month: month,
            amount: amount,
            description: description
        )
        
        // Valida a despesa atualizada
        do {
            try expense.validate()
        } catch {
            errorMessage = error.localizedDescription
            viewContext.rollback() // Desfaz alterações
            return false
        }
        
        // Salva no banco de dados
        if saveContext() {
            successMessage = "Despesa atualizada com sucesso!"
            return true
        } else {
            viewContext.rollback() // Desfaz alterações
            return false
        }
    }
    
    /// Deleta uma despesa do banco de dados
    /// - Parameter expense: A despesa para deletar
    /// - Returns: True se a deleção foi bem-sucedida, false caso contrário
    @discardableResult
    func deleteExpense(_ expense: Expense) -> Bool {
        // Limpa mensagens anteriores
        clearMessages()
        
        // Deleta a despesa
        viewContext.delete(expense)
        
        // Salva a deleção
        if saveContext() {
            successMessage = "Despesa excluída com sucesso!"
            return true
        } else {
            return false
        }
    }
    
    /// Deleta múltiplas despesas de uma vez
    /// Útil para operações em lote como "deletar todas as despesas em um mês"
    ///
    /// - Parameter expenses: Array de despesas para deletar
    /// - Returns: True se todas as deleções foram bem-sucedidas, false caso contrário
    @discardableResult
    func deleteExpenses(_ expenses: [Expense]) -> Bool {
        // Limpa mensagens anteriores
        clearMessages()
        
        // Deleta todas as despesas
        expenses.forEach { viewContext.delete($0) }
        
        // Salva as deleções
        if saveContext() {
            successMessage = "\(expenses.count) despesa(s) excluída(s) com sucesso!"
            return true
        } else {
            return false
        }
    }
    
    // MARK: - Métodos de Cálculo
    
    /// Calcula o valor total para um mês específico
    /// - Parameter month: O mês para calcular o total
    /// - Returns: O valor total como um Double
    func totalForMonth(_ month: ExpenseMonth) -> Double {
        let request = Expense.fetchRequest(for: month)
        
        do {
            let expenses = try viewContext.fetch(request)
            return expenses.reduce(0) { $0 + $1.amountValue }
        } catch {
            print("Erro ao calcular total do mês: \(error)")
            return 0
        }
    }
    
    /// Calcula o valor total para uma categoria específica
    /// - Parameter category: A categoria para calcular o total
    /// - Returns: O valor total como um Double
    func totalForCategory(_ category: ExpenseCategory) -> Double {
        let request = Expense.fetchRequest(for: category)
        
        do {
            let expenses = try viewContext.fetch(request)
            return expenses.reduce(0) { $0 + $1.amountValue }
        } catch {
            print("Erro ao calcular total da categoria: \(error)")
            return 0
        }
    }
    
    /// Calcula o valor total para um mês e categoria específicos
    /// - Parameters:
    ///   - month: O mês para filtrar
    ///   - category: A categoria para filtrar
    /// - Returns: O valor total como um Double
    func totalForMonthAndCategory(_ month: ExpenseMonth, _ category: ExpenseCategory) -> Double {
        let request = Expense.fetchRequest(for: month, category: category)
        
        do {
            let expenses = try viewContext.fetch(request)
            return expenses.reduce(0) { $0 + $1.amountValue }
        } catch {
            print("Erro ao calcular total: \(error)")
            return 0
        }
    }
    
    /// Calcula o total geral de todas as despesas
    /// - Returns: O valor total como um Double
    func grandTotal() -> Double {
        let request = Expense.fetchRequest()
        
        do {
            let expenses = try viewContext.fetch(request)
            return expenses.reduce(0) { $0 + $1.amountValue }
        } catch {
            print("Erro ao calcular total geral: \(error)")
            return 0
        }
    }
    
    /// Obtém a contagem de despesas para um mês específico
    /// - Parameter month: O mês para contar despesas
    /// - Returns: O número de despesas
    func expenseCountForMonth(_ month: ExpenseMonth) -> Int {
        let request = Expense.fetchRequest(for: month)
        
        do {
            return try viewContext.count(for: request)
        } catch {
            print("Erro ao contar despesas: \(error)")
            return 0
        }
    }
    
    // MARK: - Métodos Auxiliares
    
    /// Salva o contexto do Core Data
    /// Isso persiste todas as alterações no banco de dados
    ///
    /// - Returns: True se o salvamento foi bem-sucedido, false caso contrário
    private func saveContext() -> Bool {
        if viewContext.hasChanges {
            do {
                try viewContext.save()
                return true
            } catch {
                let nsError = error as NSError
                errorMessage = "Erro ao salvar: \(nsError.localizedDescription)"
                print("Erro ao salvar contexto: \(nsError), \(nsError.userInfo)")
                return false
            }
        }
        return true
    }
    
    /// Limpa todas as mensagens (erro e sucesso)
    /// Chame isso antes de iniciar uma nova operação
    func clearMessages() {
        errorMessage = nil
        successMessage = nil
    }
    
    /// Formata um valor Double como moeda Real Brasileiro
    /// - Parameter amount: O valor para formatar
    /// - Returns: String formatada (ex: "R$ 150,00")
    func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.currencyCode = "BRL"
        return formatter.string(from: NSNumber(value: amount)) ?? "R$ 0,00"
    }
    
    /// Reseta todos os filtros para valores padrão
    func resetFilters() {
        selectedMonth = ExpenseMonth.current
        selectedCategory = nil
    }
}

// MARK: - Auxiliar de Preview

#if DEBUG
extension ExpenseViewModel {
    /// Cria uma instância de preview com dados de exemplo
    /// Use isso em previews do SwiftUI
    static var preview: ExpenseViewModel {
        let viewModel = ExpenseViewModel(context: PersistenceController.preview.container.viewContext)
        return viewModel
    }
}
#endif

/*
 GUIA PARA INICIANTES SOBRE O USO DESTE VIEWMODEL:
 
 1. Inicializar na sua view:
    @StateObject private var viewModel = ExpenseViewModel(
        context: PersistenceController.shared.container.viewContext
    )
 
 2. Criar uma nova despesa:
    viewModel.createExpense(
        category: .energia,
        month: .janeiro,
        amount: 150.00,
        description: "Conta de luz"
    )
 
 3. Atualizar uma despesa:
    viewModel.updateExpense(
        expense,
        category: .internet,
        month: .fevereiro,
        amount: 200.00,
        description: "Nova descrição"
    )
 
 4. Deletar uma despesa:
    viewModel.deleteExpense(expense)
 
 5. Obter totais:
    let monthTotal = viewModel.totalForMonth(.janeiro)
    let categoryTotal = viewModel.totalForCategory(.energia)
    let grandTotal = viewModel.grandTotal()
 
 6. Lidar com mensagens de erro e sucesso:
    if let error = viewModel.errorMessage {
        // Mostrar alerta de erro
    }
    if let success = viewModel.successMessage {
        // Mostrar mensagem de sucesso
    }
 
 7. Usar filtros:
    viewModel.selectedMonth = .fevereiro
    viewModel.selectedCategory = .energia
 
 POR QUE USAR UM VIEWMODEL?
 - Separa lógica de negócios do código de UI
 - Torna os testes mais fáceis (pode testar lógica sem UI)
 - Centraliza o gerenciamento de estado
 - Fornece uma única fonte de verdade para dados
 - Torna o código mais manutenível e reutilizável
 - Segue o padrão de arquitetura MVVM (Model-View-ViewModel)
 */

// Feito com Bob