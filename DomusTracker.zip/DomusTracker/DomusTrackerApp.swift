//
//  DomusTrackerApp.swift
//  DomusTracker
//
//  Propósito: Ponto de entrada principal para o aplicativo iOS DomusTracker
//  Este arquivo configura a estrutura do aplicativo e injeta o contexto do Core Data
//

import SwiftUI

/// DomusTrackerApp é o ponto de entrada principal para a aplicação
/// Ele está em conformidade com o protocolo App, que é necessário para todos os aplicativos SwiftUI
@main
struct DomusTrackerApp: App {
    
    // MARK: - Propriedades
    
    /// O controlador de persistência do Core Data
    /// Ele gerencia toda a pilha do Core Data para o aplicativo
    /// Usamos @StateObject para garantir que persista durante toda a vida útil do aplicativo
    @StateObject private var persistenceController = PersistenceController.shared
    
    // MARK: - Configuração de Cena
    
    /// A propriedade body define a estrutura de cena do aplicativo
    /// Uma cena representa uma parte da interface do usuário do seu aplicativo
    var body: some Scene {
        WindowGroup {
            ContentView()
                // Injeta o contexto de objeto gerenciado do Core Data no ambiente
                // Isso o torna disponível para todas as views filhas
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}

/*
 GUIA PARA INICIANTES SOBRE O PONTO DE ENTRADA DO APLICATIVO:
 
 1. Atributo @main:
    - Marca este como o ponto de entrada do aplicativo
    - Swift procura por @main para saber onde começar
    - Apenas um @main por aplicativo
 
 2. Protocolo App:
    - Todos os aplicativos SwiftUI devem estar em conformidade com o protocolo App
    - Requer uma propriedade body que retorna uma Scene
    - Define a estrutura e o comportamento do aplicativo
 
 3. WindowGroup:
    - Uma Scene que gerencia uma ou mais janelas
    - No iOS, normalmente mostra uma janela
    - No macOS, pode mostrar várias janelas
 
 4. Injeção do Core Data:
    - PersistenceController.shared fornece a pilha do Core Data
    - .environment(\.managedObjectContext, ...) injeta na hierarquia de views
    - Todas as views filhas podem acessá-lo com @Environment(\.managedObjectContext)
 
 5. @StateObject:
    - Cria e possui o PersistenceController
    - Garante que persista durante toda a vida útil do aplicativo
    - SwiftUI gerencia seu ciclo de vida
 
 6. Por que Esta Estrutura?
    - Simples: Código de configuração mínimo
    - Limpo: Separação de responsabilidades
    - Testável: Fácil de injetar diferentes contextos para testes
    - Padrão: Segue as melhores práticas do SwiftUI
 
 CICLO DE VIDA DO APLICATIVO:
 1. Aplicativo é iniciado
 2. DomusTrackerApp é criado
 3. PersistenceController é inicializado
 4. Pilha do Core Data é configurada
 5. ContentView é criada com contexto injetado
 6. Usuário interage com o aplicativo
 7. Todas as views têm acesso ao Core Data
 
 INJEÇÃO DE AMBIENTE:
 - .environment(\.managedObjectContext, ...) injeta o contexto do Core Data
 - Disponível para todas as views filhas automaticamente
 - Views acessam com: @Environment(\.managedObjectContext) private var viewContext
 - Não é necessário passá-lo manualmente pela hierarquia de views
 
 TESTES E PREVIEWS:
 - Para previews, use: PersistenceController.preview.container.viewContext
 - Para testes, crie um controlador personalizado em memória
 - Esta estrutura torna os testes fáceis e isolados
 
 OPÇÕES DE CUSTOMIZAÇÃO:
 - Adicione modificadores em todo o aplicativo aqui (tema, fontes, etc.)
 - Configure a aparência do aplicativo
 - Configure o gerenciamento de estado no nível do aplicativo
 - Inicialize serviços ou gerenciadores
 
 Exemplo com customização:
 
 var body: some Scene {
     WindowGroup {
         ContentView()
             .environment(\.managedObjectContext, persistenceController.container.viewContext)
             .accentColor(.blue)  // Cor de destaque em todo o aplicativo
             .preferredColorScheme(.light)  // Forçar modo claro
     }
 }
 
 ADIÇÕES COMUNS:
 - Gerenciamento de estado do aplicativo (@StateObject para estado em todo o aplicativo)
 - Configuração de deep linking
 - Configuração de notificações push
 - Inicialização de analytics
 - Configuração de SDKs de terceiros
 
 POR QUE CÓDIGO MÍNIMO?
 - SwiftUI lida com a maior parte do ciclo de vida do aplicativo automaticamente
 - Menos código boilerplate do que UIKit
 - Foco no conteúdo do aplicativo, não na configuração
 - Fácil de entender e manter
 
 COMPARAÇÃO COM UIKit:
 - UIKit: AppDelegate, SceneDelegate, storyboards
 - SwiftUI: Apenas este arquivo e suas views
 - Muito mais simples e declarativo
 */

// Feito com Bob