//
//  PersistenceController.swift
//  DomusTracker
//
//  Propósito: Gerencia a pilha do Core Data para a aplicação
//  Este arquivo configura o Core Data, que é o framework da Apple
//  para salvar dados localmente no dispositivo.
//

import CoreData

/// PersistenceController é responsável por gerenciar a pilha do Core Data
/// Ele usa o padrão Singleton, o que significa que há apenas uma instância em todo o aplicativo
/// Isso garante que todas as partes do aplicativo usem a mesma conexão de banco de dados
struct PersistenceController {
    
    // MARK: - Instância Singleton
    
    /// A instância compartilhada usada em todo o aplicativo
    /// Esta é a instância principal que você usará em produção
    static let shared = PersistenceController()
    
    /// Uma instância de preview para previews do SwiftUI
    /// Isso cria um banco de dados temporário em memória que é perfeito para testes
    /// e visualização da sua interface sem afetar dados reais
    static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let viewContext = result.container.viewContext
        
        // Cria dados de exemplo para previews
        // Isso ajuda você a ver como sua interface fica com dados reais
        for i in 0..<5 {
            let newExpense = Expense(context: viewContext)
            newExpense.id = UUID()
            newExpense.category = ["Energia", "Internet", "Água", "Mercado", "Lazer"][i]
            newExpense.month = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio"][i]
            newExpense.amount = NSDecimalNumber(value: Double.random(in: 50...500))
            newExpense.descriptionText = "Despesa de exemplo \(i + 1)"
            newExpense.createdAt = Date()
            newExpense.updatedAt = Date()
        }
        
        // Salva os dados de exemplo
        do {
            try viewContext.save()
        } catch {
            // Se o salvamento falhar, obteremos informações detalhadas do erro
            let nsError = error as NSError
            fatalError("Erro ao criar dados de preview: \(nsError), \(nsError.userInfo)")
        }
        
        return result
    }()
    
    // MARK: - Container do Core Data
    
    /// O container persistente é o objeto principal do Core Data
    /// Ele gerencia a pilha do Core Data incluindo:
    /// - O modelo de dados (suas definições de entidade)
    /// - O coordenador de armazenamento persistente (gerencia o arquivo do banco de dados)
    /// - O contexto de objeto gerenciado (onde você trabalha com seus dados)
    let container: NSPersistentContainer
    
    // MARK: - Inicialização
    
    /// Inicializa a pilha do Core Data
    /// - Parameter inMemory: Se true, os dados são armazenados apenas na memória (útil para testes)
    ///                       Se false, os dados são salvos no disco (comportamento normal do aplicativo)
    init(inMemory: Bool = false) {
        // Cria o container com o nome do seu arquivo de modelo de dados
        // Este nome deve corresponder ao nome do seu arquivo .xcdatamodeld
        container = NSPersistentContainer(name: "DomusTracker")
        
        if inMemory {
            // Para testes/previews: armazena dados apenas na memória
            // Isso significa que os dados desaparecem quando o aplicativo fecha
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        
        // Carrega os armazenamentos persistentes (isso realmente abre/cria o banco de dados)
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                // Se houver um erro ao carregar o banco de dados, precisamos saber sobre isso
                // Em um aplicativo de produção, você pode querer lidar com isso de forma mais elegante
                // Para fins de aprendizado, vamos travar com informações detalhadas
                
                /*
                 Possíveis razões para erros:
                 - Espaço de armazenamento insuficiente
                 - Arquivo de banco de dados corrompido
                 - Problemas de permissões
                 - Incompatibilidade de versão do modelo (após atualizações)
                 
                 Em produção, você pode:
                 - Mostrar uma mensagem de erro ao usuário
                 - Tentar recuperar deletando e recriando o banco de dados
                 - Registrar o erro em um serviço de relatório de crashes
                 */
                
                fatalError("Erro ao carregar Core Data: \(error), \(error.userInfo)")
            }
        }
        
        // Configura o contexto de view para melhor desempenho
        // O contexto de view é onde você fará a maior parte do seu trabalho com Core Data
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        /*
         O que automaticallyMergesChangesFromParent faz?
         - Se você fizer alterações em um contexto de background (por exemplo, sincronizando dados)
         - Essas alterações aparecerão automaticamente na sua interface
         - Sem isso, você precisaria atualizar manualmente suas views
         */
    }
    
    // MARK: - Métodos Auxiliares
    
    /// Salva qu aisquer alterações pendentes no contexto de view
    /// Chame isso após fazer alterações nos seus dados
    func save() {
        let context = container.viewContext
        
        // Salva apenas se houver alterações reais
        // Isso é mais eficiente do que salvar toda vez
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Se o salvamento falhar, precisamos saber por quê
                let nsError = error as NSError
                print("Erro ao salvar contexto: \(nsError), \(nsError.userInfo)")
                
                /*
                 Em um aplicativo real, você pode querer:
                 - Mostrar um alerta ao usuário
                 - Tentar salvar novamente
                 - Reverter as alterações
                 - Registrar o erro para depuração
                 */
            }
        }
    }
    
    /// Deleta um objeto do Core Data
    /// - Parameter object: O objeto gerenciado para deletar
    func delete(_ object: NSManagedObject) {
        let context = container.viewContext
        context.delete(object)
        save() // Salva a deleção
    }
    
    /// Deleta todos os dados de uma entidade específica
    /// Útil para testes ou implementar uma funcionalidade de "limpar todos os dados"
    /// - Parameter entityName: O nome da entidade para limpar (ex: "Expense")
    func deleteAll(entityName: String) {
        let context = container.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try context.execute(deleteRequest)
            save()
        } catch {
            let nsError = error as NSError
            print("Erro ao deletar todos os dados: \(nsError), \(nsError.userInfo)")
        }
    }
}

/*
 GUIA PARA INICIANTES SOBRE O USO DESTE ARQUIVO:
 
 1. Nas suas views SwiftUI, injete o contexto de objeto gerenciado:
    @Environment(\.managedObjectContext) private var viewContext
 
 2. No ponto de entrada do seu aplicativo (DomusTrackerApp.swift), configure o ambiente:
    .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
 
 3. Para buscar dados no SwiftUI, use @FetchRequest:
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Expense.createdAt, ascending: false)],
        animation: .default)
    private var expenses: FetchedResults<Expense>
 
 4. Para criar novos dados:
    let newExpense = Expense(context: viewContext)
    newExpense.id = UUID()
    newExpense.category = "Energia"
    // ... definir outras propriedades
    PersistenceController.shared.save()
 
 5. Para deletar dados:
    PersistenceController.shared.delete(expense)
 
 6. Para previews, use a instância de preview:
    .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
 */

// Feito com Bob
