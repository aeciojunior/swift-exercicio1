//
//  DateFormatter+Extensions.swift
//  DomusTracker
//
//  Propósito: Fornece extensões utilitárias para formatação de datas
//  Este arquivo centraliza toda a lógica de formatação de datas para o aplicativo
//

import Foundation

/// Extensão para DateFormatter para fornecer métodos convenientes de formatação de datas
/// Esses métodos garantem formatação de data consistente em todo o aplicativo
extension DateFormatter {
    
    // MARK: - Formatadores Compartilhados
    
    /// Formatador para formato de data longo
    /// Exemplo: "20 de maio de 2026"
    static let longDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateStyle = .long
        formatter.timeStyle = .none
        return formatter
    }()
    
    /// Formatador para formato de data médio
    /// Exemplo: "20/05/2026"
    static let mediumDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter
    }()
    
    /// Formatador para formato de data curto
    /// Exemplo: "20/05/26"
    static let shortDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter
    }()
    
    /// Formatador para data e hora
    /// Exemplo: "20/05/2026 às 14:30"
    static let dateTime: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateFormat = "dd/MM/yyyy 'às' HH:mm"
        return formatter
    }()
    
    /// Formatador apenas para hora
    /// Exemplo: "14:30"
    static let timeOnly: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        return formatter
    }()
    
    /// Formatador para mês e ano
    /// Exemplo: "Maio de 2026"
    static let monthYear: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateFormat = "MMMM 'de' yyyy"
        return formatter
    }()
    
    /// Formatador para dia e mês
    /// Exemplo: "20 de maio"
    static let dayMonth: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.dateFormat = "dd 'de' MMMM"
        return formatter
    }()
    
    /// Formatador para formato ISO 8601 (para chamadas de API ou armazenamento)
    /// Exemplo: "2026-05-20T14:30:00Z"
    static let iso8601: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        return formatter
    }()
    
    /// Formatador para strings de data relativa
    /// Exemplo: "Hoje", "Ontem", "20/05/2026"
    static func relativeDate(from date: Date) -> String {
        let calendar = Calendar.current
        
        if calendar.isDateInToday(date) {
            return "Hoje"
        } else if calendar.isDateInYesterday(date) {
            return "Ontem"
        } else if calendar.isDateInTomorrow(date) {
            return "Amanhã"
        } else {
            return mediumDate.string(from: date)
        }
    }
}

// MARK: - Extensões de Date

extension Date {
    
    /// Formata esta data como uma string de data longa
    /// Exemplo: "20 de maio de 2026"
    var asLongDate: String {
        return DateFormatter.longDate.string(from: self)
    }
    
    /// Formata esta data como uma string de data média
    /// Exemplo: "20/05/2026"
    var asMediumDate: String {
        return DateFormatter.mediumDate.string(from: self)
    }
    
    /// Formata esta data como uma string de data curta
    /// Exemplo: "20/05/26"
    var asShortDate: String {
        return DateFormatter.shortDate.string(from: self)
    }
    
    /// Formata esta data como uma string de data e hora
    /// Exemplo: "20/05/2026 às 14:30"
    var asDateTime: String {
        return DateFormatter.dateTime.string(from: self)
    }
    
    /// Formata esta data como uma string apenas de hora
    /// Exemplo: "14:30"
    var asTimeOnly: String {
        return DateFormatter.timeOnly.string(from: self)
    }
    
    /// Formata esta data como mês e ano
    /// Exemplo: "Maio de 2026"
    var asMonthYear: String {
        return DateFormatter.monthYear.string(from: self)
    }
    
    /// Formata esta data como dia e mês
    /// Exemplo: "20 de maio"
    var asDayMonth: String {
        return DateFormatter.dayMonth.string(from: self)
    }
    
    /// Formata esta data como uma string de data relativa
    /// Exemplo: "Hoje", "Ontem", ou "20/05/2026"
    var asRelativeDate: String {
        return DateFormatter.relativeDate(from: self)
    }
    
    /// Retorna true se esta data é hoje
    var isToday: Bool {
        return Calendar.current.isDateInToday(self)
    }
    
    /// Retorna true se esta data é ontem
    var isYesterday: Bool {
        return Calendar.current.isDateInYesterday(self)
    }
    
    /// Retorna true se esta data é amanhã
    var isTomorrow: Bool {
        return Calendar.current.isDateInTomorrow(self)
    }
    
    /// Retorna true se esta data está na semana atual
    var isThisWeek: Bool {
        return Calendar.current.isDate(self, equalTo: Date(), toGranularity: .weekOfYear)
    }
    
    /// Retorna true se esta data está no mês atual
    var isThisMonth: Bool {
        return Calendar.current.isDate(self, equalTo: Date(), toGranularity: .month)
    }
    
    /// Retorna true se esta data está no ano atual
    var isThisYear: Bool {
        return Calendar.current.isDate(self, equalTo: Date(), toGranularity: .year)
    }
    
    /// Retorna o início do dia para esta data
    /// Exemplo: 2026-05-20 14:30:00 → 2026-05-20 00:00:00
    var startOfDay: Date {
        return Calendar.current.startOfDay(for: self)
    }
    
    /// Retorna o fim do dia para esta data
    /// Exemplo: 2026-05-20 14:30:00 → 2026-05-20 23:59:59
    var endOfDay: Date {
        var components = DateComponents()
        components.day = 1
        components.second = -1
        return Calendar.current.date(byAdding: components, to: startOfDay) ?? self
    }
    
    /// Retorna o início do mês para esta data
    var startOfMonth: Date {
        let components = Calendar.current.dateComponents([.year, .month], from: self)
        return Calendar.current.date(from: components) ?? self
    }
    
    /// Retorna o fim do mês para esta data
    var endOfMonth: Date {
        var components = DateComponents()
        components.month = 1
        components.second = -1
        return Calendar.current.date(byAdding: components, to: startOfMonth) ?? self
    }
    
    /// Retorna o número de dias entre esta data e outra data
    /// - Parameter date: A data para comparar
    /// - Returns: O número de dias entre as datas
    func daysBetween(_ date: Date) -> Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.day], from: self.startOfDay, to: date.startOfDay)
        return abs(components.day ?? 0)
    }
    
    /// Retorna uma data adicionando um número de dias
    /// - Parameter days: O número de dias para adicionar (pode ser negativo)
    /// - Returns: A nova data
    func addingDays(_ days: Int) -> Date {
        return Calendar.current.date(byAdding: .day, value: days, to: self) ?? self
    }
    
    /// Retorna uma data adicionando um número de meses
    /// - Parameter months: O número de meses para adicionar (pode ser negativo)
    /// - Returns: A nova data
    func addingMonths(_ months: Int) -> Date {
        return Calendar.current.date(byAdding: .month, value: months, to: self) ?? self
    }
    
    /// Retorna o número do mês (1-12) para esta data
    var monthNumber: Int {
        return Calendar.current.component(.month, from: self)
    }
    
    /// Retorna o ano para esta data
    var year: Int {
        return Calendar.current.component(.year, from: self)
    }
    
    /// Retorna o dia do mês para esta data
    var day: Int {
        return Calendar.current.component(.day, from: self)
    }
    
    /// Retorna o enum ExpenseMonth para esta data
    var asExpenseMonth: ExpenseMonth? {
        return ExpenseMonth.from(number: monthNumber)
    }
}

// MARK: - Extensões de String

extension String {
    /// Analisa esta string como uma data usando o formato de data médio
    /// Exemplo: "20/05/2026" → Date
    var asMediumDate: Date? {
        return DateFormatter.mediumDate.date(from: self)
    }
    
    /// Analisa esta string como uma data usando o formato ISO 8601
    /// Exemplo: "2026-05-20T14:30:00Z" → Date
    var asISO8601Date: Date? {
        return DateFormatter.iso8601.date(from: self)
    }
}

/*
 GUIA PARA INICIANTES SOBRE O USO DESTAS EXTENSÕES:
 
 1. Formatar uma data como data longa:
    let date = Date()
    let formatted = date.asLongDate
    // Resultado: "20 de maio de 2026"
 
 2. Formatar uma data como data e hora:
    let date = Date()
    let formatted = date.asDateTime
    // Resultado: "20/05/2026 às 14:30"
 
 3. Obter uma string de data relativa:
    let date = Date()
    let formatted = date.asRelativeDate
    // Resultado: "Hoje" (se a data for hoje)
 
 4. Verificar se uma data é hoje:
    let date = Date()
    if date.isToday {
        print("Isso é hoje!")
    }
 
 5. Obter o início do dia:
    let date = Date()
    let startOfDay = date.startOfDay
    // Resultado: Hoje às 00:00:00
 
 6. Calcular dias entre datas:
    let date1 = Date()
    let date2 = date1.addingDays(5)
    let days = date1.daysBetween(date2)
    // Resultado: 5
 
 7. Adicionar dias ou meses a uma data:
    let date = Date()
    let tomorrow = date.addingDays(1)
    let nextMonth = date.addingMonths(1)
 
 8. Obter informações do mês:
    let date = Date()
    let monthNumber = date.monthNumber  // 1-12
    let expenseMonth = date.asExpenseMonth  // Enum ExpenseMonth
 
 9. Analisar uma string de data:
    let dateString = "20/05/2026"
    if let date = dateString.asMediumDate {
        print(date)
    }
 
 POR QUE USAR ESTAS EXTENSÕES?
 - Conveniência: Métodos fáceis de usar para operações comuns de data
 - Consistência: Todas as datas são formatadas da mesma forma
 - Localização: Formatado adequadamente para português brasileiro
 - Legibilidade: Código é mais legível com nomes de propriedades descritivos
 - Manutenibilidade: Fácil de mudar formatação em um lugar
 */

// Feito com Bob