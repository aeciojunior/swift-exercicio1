//
//  CurrencyFormatter.swift
//  DomusTracker
//
//  Propósito: Fornece funções utilitárias para formatação de valores monetários
//  Este arquivo centraliza toda a lógica de formatação de moeda para Real Brasileiro (BRL)
//

import Foundation

/// CurrencyFormatter fornece métodos para formatar números como moeda Real Brasileiro
/// Isso garante formatação de moeda consistente em todo o aplicativo
struct CurrencyFormatter {
    
    // MARK: - Instância Compartilhada
    
    /// Instância compartilhada para fácil acesso em todo o aplicativo
    /// Usar uma instância compartilhada garante que reutilizemos a mesma configuração do formatador
    static let shared = CurrencyFormatter()
    
    // MARK: - Propriedades Privadas
    
    /// O NumberFormatter configurado para Real Brasileiro
    /// Isso é criado uma vez e reutilizado para melhor desempenho
    private let formatter: NumberFormatter
    
    // MARK: - Inicialização
    
    /// Inicializador privado para configurar o formatador
    /// Isso é privado porque queremos usar a instância compartilhada
    private init() {
        formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "pt_BR")
        formatter.currencyCode = "BRL"
        formatter.currencySymbol = "R$"
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 2
    }
    
    // MARK: - Métodos de Formatação
    
    /// Formata um valor Double como moeda Real Brasileiro
    /// Exemplo: 150.50 → "R$ 150,50"
    ///
    /// - Parameter amount: O valor a ser formatado
    /// - Returns: String de moeda formatada
    func format(_ amount: Double) -> String {
        return formatter.string(from: NSNumber(value: amount)) ?? "R$ 0,00"
    }
    
    /// Formata um valor Decimal como moeda Real Brasileiro
    /// Exemplo: 150.50 → "R$ 150,50"
    ///
    /// - Parameter amount: O valor a ser formatado
    /// - Returns: String de moeda formatada
    func format(_ amount: Decimal) -> String {
        return formatter.string(from: amount as NSDecimalNumber) ?? "R$ 0,00"
    }
    
    /// Formata um NSDecimalNumber como moeda Real Brasileiro
    /// Exemplo: 150.50 → "R$ 150,50"
    ///
    /// - Parameter amount: O valor a ser formatado
    /// - Returns: String de moeda formatada
    func format(_ amount: NSDecimalNumber) -> String {
        return formatter.string(from: amount) ?? "R$ 0,00"
    }
    
    /// Formata um valor Double como moeda sem o símbolo de moeda
    /// Exemplo: 150.50 → "150,50"
    ///
    /// - Parameter amount: O valor a ser formatado
    /// - Returns: String de número formatada sem símbolo de moeda
    func formatWithoutSymbol(_ amount: Double) -> String {
        let tempFormatter = NumberFormatter()
        tempFormatter.numberStyle = .decimal
        tempFormatter.locale = Locale(identifier: "pt_BR")
        tempFormatter.maximumFractionDigits = 2
        tempFormatter.minimumFractionDigits = 2
        return tempFormatter.string(from: NSNumber(value: amount)) ?? "0,00"
    }
    
    /// Analisa uma string de moeda e retorna um valor Double
    /// Exemplo: "R$ 150,50" → 150.50
    ///
    /// - Parameter string: A string de moeda para analisar
    /// - Returns: O valor Double analisado, ou nil se a análise falhar
    func parse(_ string: String) -> Double? {
        // Remove símbolo de moeda e espaços em branco
        let cleanString = string
            .replacingOccurrences(of: "R$", with: "")
            .replacingOccurrences(of: " ", with: "")
            .trimmingCharacters(in: .whitespaces)
        
        // Tenta analisar com o formatador
        if let number = formatter.number(from: cleanString) {
            return number.doubleValue
        }
        
        // Se isso falhar, tenta substituir vírgula por ponto para separador decimal
        let dotString = cleanString.replacingOccurrences(of: ",", with: ".")
        return Double(dotString)
    }
    
    /// Valida se uma string é um valor de moeda válido
    /// - Parameter string: A string para validar
    /// - Returns: True se a string representa um valor de moeda válido
    func isValid(_ string: String) -> Bool {
        return parse(string) != nil
    }
    
    /// Formata uma string de moeda para exibição em um campo de texto
    /// Isso é útil para formatação em tempo real enquanto o usuário digita
    ///
    /// - Parameter string: A string de entrada
    /// - Returns: String formatada adequada para exibição em campo de texto
    func formatForTextField(_ string: String) -> String {
        // Remove todos os caracteres não numéricos exceto vírgula e ponto
        let cleanString = string.components(separatedBy: CharacterSet(charactersIn: "0123456789,.").inverted).joined()
        
        // Analisa e formata
        if let value = parse(cleanString) {
            return formatWithoutSymbol(value)
        }
        
        return cleanString
    }
}

// MARK: - Extensões de Conveniência

extension Double {
    /// Formata este Double como moeda Real Brasileiro
    /// Exemplo: 150.50.asCurrency → "R$ 150,50"
    var asCurrency: String {
        return CurrencyFormatter.shared.format(self)
    }
    
    /// Formata este Double como um número sem símbolo de moeda
    /// Exemplo: 150.50.asFormattedNumber → "150,50"
    var asFormattedNumber: String {
        return CurrencyFormatter.shared.formatWithoutSymbol(self)
    }
}

extension Decimal {
    /// Formata este Decimal como moeda Real Brasileiro
    /// Exemplo: 150.50.asCurrency → "R$ 150,50"
    var asCurrency: String {
        return CurrencyFormatter.shared.format(self)
    }
}

extension NSDecimalNumber {
    /// Formata este NSDecimalNumber como moeda Real Brasileiro
    /// Exemplo: 150.50.asCurrency → "R$ 150,50"
    var asCurrency: String {
        return CurrencyFormatter.shared.format(self)
    }
}

extension String {
    /// Analisa esta string como um valor de moeda
    /// Exemplo: "R$ 150,50".asCurrencyValue → 150.50
    var asCurrencyValue: Double? {
        return CurrencyFormatter.shared.parse(self)
    }
    
    /// Verifica se esta string é um valor de moeda válido
    /// Exemplo: "R$ 150,50".isValidCurrency → true
    var isValidCurrency: Bool {
        return CurrencyFormatter.shared.isValid(self)
    }
}

/*
 GUIA PARA INICIANTES SOBRE O USO DESTE FORMATADOR:
 
 1. Formatar um Double como moeda:
    let amount = 150.50
    let formatted = CurrencyFormatter.shared.format(amount)
    // Resultado: "R$ 150,50"
 
 2. Usar a extensão de conveniência:
    let amount = 150.50
    let formatted = amount.asCurrency
    // Resultado: "R$ 150,50"
 
 3. Analisar uma string de moeda:
    let string = "R$ 150,50"
    if let value = CurrencyFormatter.shared.parse(string) {
        print(value) // 150.5
    }
 
 4. Usar a extensão String:
    let string = "R$ 150,50"
    if let value = string.asCurrencyValue {
        print(value) // 150.5
    }
 
 5. Validar entrada de moeda:
    let input = "R$ 150,50"
    if input.isValidCurrency {
        // Formato de moeda válido
    }
 
 6. Formatar para campo de texto (sem símbolo):
    let amount = 150.50
    let formatted = CurrencyFormatter.shared.formatWithoutSymbol(amount)
    // Resultado: "150,50"
 
 POR QUE USAR UM FORMATADOR CENTRALIZADO?
 - Consistência: Todos os valores de moeda são formatados da mesma forma
 - Manutenibilidade: Fácil de mudar regras de formatação em um lugar
 - Localização: Fácil de suportar diferentes locales no futuro
 - Desempenho: Reutiliza a mesma instância do formatador
 - Type Safety: Extensões fornecem formatação type-safe
 */

// Feito com Bob