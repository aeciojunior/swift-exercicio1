import SwiftUI

@main
struct CRUD_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContactListView()
        }
    }
}
