import Foundation
import SwiftUI
import Combine

@MainActor
public class ContactListViewModel: ObservableObject {
    @Published public var contacts: [Contact] = []
    @Published public var isLoading: Bool = false
    @Published public var errorMessage: String? = nil
    @Published public var searchQuery: String = ""
    
    // Repository instances
    public let inMemoryRepo = InMemoryContactRepository()
    public let coreDataRepo = CoreDataContactRepository()
    public let apiRepo = APIContactRepository()
    
    @Published public var activeRepositoryType: RepositoryType = .coreData {
        didSet {
            Task {
                await fetchContacts()
            }
        }
    }
    
    public enum RepositoryType: String, CaseIterable, Identifiable {
        case inMemory = "Vetor (Memória)"
        case coreData = "Core Data (SQLite)"
        case api = "API Remota (Simulada)"
        
        public var id: String { self.rawValue }
    }
    
    public var currentRepository: ContactRepository {
        switch activeRepositoryType {
        case .inMemory: return inMemoryRepo
        case .coreData: return coreDataRepo
        case .api: return apiRepo
        }
    }
    
    public var filteredContacts: [Contact] {
        if searchQuery.isEmpty {
            return contacts
        } else {
            return contacts.filter { contact in
                contact.name.localizedCaseInsensitiveContains(searchQuery) ||
                contact.email.localizedCaseInsensitiveContains(searchQuery) ||
                contact.city.localizedCaseInsensitiveContains(searchQuery) ||
                contact.phone.localizedCaseInsensitiveContains(searchQuery)
            }
        }
    }
    
    public init() {
        Task {
            await fetchContacts()
        }
    }
    
    public func fetchContacts() async {
        isLoading = true
        errorMessage = nil
        do {
            self.contacts = try await currentRepository.fetchContacts()
        } catch {
            errorMessage = "Erro ao buscar contatos: \(error.localizedDescription)"
        }
        isLoading = false
    }
    
    public func deleteContact(_ contact: Contact) async {
        isLoading = true
        errorMessage = nil
        do {
            try await currentRepository.delete(contact: contact)
            self.contacts = try await currentRepository.fetchContacts()
        } catch {
            errorMessage = "Erro ao excluir contato: \(error.localizedDescription)"
        }
        isLoading = false
    }
}
