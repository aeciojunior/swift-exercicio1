import Foundation
import SwiftUI
import Combine

@MainActor
public class ContactFormViewModel: ObservableObject {
    private let viaCEPService = ViaCEPService()
    
    @Published public var name: String = ""
    @Published public var email: String = ""
    @Published public var phone: String = ""
    @Published public var birthDate: Date = Calendar.current.date(byAdding: .year, value: -20, to: Date()) ?? Date()
    @Published public var cep: String = "" {
        didSet {
            let clean = cep.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
            if clean.count == 8 && clean != lastQueriedCEP {
                Task {
                    await fetchAddress(for: clean)
                }
            }
        }
    }
    @Published public var neighborhood: String = ""
    @Published public var street: String = ""
    @Published public var number: String = ""
    @Published public var state: String = ""
    @Published public var city: String = ""
    
    @Published public var isCEPLoading: Bool = false
    @Published public var cepError: String? = nil
    @Published public var showValidationErrorAlert: Bool = false
    @Published public var validationErrorMessage: String = ""
    
    public var editingContact: Contact?
    private var lastQueriedCEP: String = ""
    
    public init(contact: Contact? = nil) {
        self.editingContact = contact
        if let contact = contact {
            self.name = contact.name
            self.email = contact.email
            self.phone = contact.phone
            self.birthDate = contact.birthDate
            self.cep = contact.cep
            self.neighborhood = contact.neighborhood
            self.street = contact.street
            self.number = contact.number
            self.state = contact.state
            self.city = contact.city
            self.lastQueriedCEP = contact.cep.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        }
    }
    
    public func fetchAddress(for cleanCEP: String) async {
        isCEPLoading = true
        cepError = nil
        lastQueriedCEP = cleanCEP
        
        do {
            let info = try await viaCEPService.fetchAddress(for: cleanCEP)
            self.street = info.logradouro ?? ""
            self.neighborhood = info.bairro ?? ""
            self.city = info.localidade ?? ""
            self.state = info.uf ?? ""
        } catch {
            cepError = error.localizedDescription
        }
        isCEPLoading = false
    }
    
    public func validateForm() -> Bool {
        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O nome é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        if email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O e-mail é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        let emailPattern = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailPattern)
        if !emailPred.evaluate(with: email) {
            validationErrorMessage = "Insira um e-mail válido (exemplo@dominio.com)."
            showValidationErrorAlert = true
            return false
        }
        
        if phone.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O telefone é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        let cleanCEP = cep.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        if cleanCEP.count != 8 {
            validationErrorMessage = "O CEP deve conter 8 dígitos."
            showValidationErrorAlert = true
            return false
        }
        
        if street.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O logradouro/rua é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        if number.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O número da residência é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        if neighborhood.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O bairro é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        if city.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "A cidade é obrigatória."
            showValidationErrorAlert = true
            return false
        }
        
        if state.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            validationErrorMessage = "O estado (UF) é obrigatório."
            showValidationErrorAlert = true
            return false
        }
        
        return true
    }
    
    public func save(to repository: ContactRepository) async throws {
        let contact = Contact(
            id: editingContact?.id ?? UUID(),
            name: name.trimmingCharacters(in: .whitespacesAndNewlines),
            email: email.trimmingCharacters(in: .whitespacesAndNewlines),
            phone: phone.trimmingCharacters(in: .whitespacesAndNewlines),
            birthDate: birthDate,
            cep: cep.trimmingCharacters(in: .whitespacesAndNewlines),
            neighborhood: neighborhood.trimmingCharacters(in: .whitespacesAndNewlines),
            street: street.trimmingCharacters(in: .whitespacesAndNewlines),
            number: number.trimmingCharacters(in: .whitespacesAndNewlines),
            state: state.trimmingCharacters(in: .whitespacesAndNewlines).uppercased(),
            city: city.trimmingCharacters(in: .whitespacesAndNewlines)
        )
        
        if editingContact != nil {
            try await repository.update(contact: contact)
        } else {
            try await repository.save(contact: contact)
        }
    }
}
