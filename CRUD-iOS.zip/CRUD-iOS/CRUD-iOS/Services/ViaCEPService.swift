import Foundation

public struct CEPInfo: Codable {
    public let cep: String?
    public let logradouro: String?
    public let complemento: String?
    public let bairro: String?
    public let localidade: String? // Cidade
    public let uf: String?         // Estado
    public let erro: Bool?         // True if the API returns an error for invalid/not found CEP
}

public enum ViaCEPError: Error, LocalizedError {
    case invalidCEP
    case networkError(Error)
    case invalidResponse
    case cepNotFound
    
    public var errorDescription: String? {
        switch self {
        case .invalidCEP:
            return "CEP inválido. Deve conter 8 dígitos."
        case .networkError(let error):
            return "Erro de rede: \(error.localizedDescription)"
        case .invalidResponse:
            return "Dados retornados pelo servidor são inválidos."
        case .cepNotFound:
            return "CEP não encontrado na base de dados do ViaCEP."
        }
    }
}

public class ViaCEPService {
    public init() {}
    
    /// Queries the ViaCEP API for a given CEP code.
    /// - Parameter cep: The postal code string (with or without formatting characters).
    /// - Returns: A decoded CEPInfo model.
    public func fetchAddress(for cep: String) async throws -> CEPInfo {
        // Clean characters leaving only numbers
        let cleanCEP = cep.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        
        guard cleanCEP.count == 8 else {
            throw ViaCEPError.invalidCEP
        }
        
        guard let url = URL(string: "https://viacep.com.br/ws/\(cleanCEP)/json/") else {
            throw ViaCEPError.invalidCEP
        }
        
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw ViaCEPError.invalidResponse
        }
        
        do {
            let decoder = JSONDecoder()
            let info = try decoder.decode(CEPInfo.self, from: data)
            
            if info.erro == true {
                throw ViaCEPError.cepNotFound
            }
            
            return info
        } catch let error as ViaCEPError {
            throw error
        } catch {
            throw ViaCEPError.invalidResponse
        }
    }
}
