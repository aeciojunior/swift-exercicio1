import SwiftUI

struct ContactDetailView: View {
    @ObservedObject var listViewModel: ContactListViewModel
    let contact: Contact
    
    @Environment(\.dismiss) var dismiss
    @State private var showEditSheet = false
    @State private var showDeleteAlert = false
    @State private var isDeleting = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // Header Profile Section
                VStack(spacing: 12) {
                    Circle()
                        .fill(LinearGradient(gradient: Gradient(colors: [.indigo, .purple]), startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 100, height: 100)
                        .shadow(color: .indigo.opacity(0.3), radius: 8, x: 0, y: 4)
                        .overlay(
                            Text(getInitials(from: contact.name))
                                .font(.system(size: 36, weight: .bold))
                                .foregroundColor(.white)
                        )
                    
                    Text(contact.name)
                        .font(.title2)
                        .bold()
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.center)
                    
                    Text("Armazenado em: \(listViewModel.currentRepository.name)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                }
                .padding(.top, 16)
                
                // Quick Actions Section
                HStack(spacing: 24) {
                    ActionButton(title: "Ligar", icon: "phone.fill", color: .green) {
                        callContact()
                    }
                    
                    ActionButton(title: "E-mail", icon: "envelope.fill", color: .blue) {
                        emailContact()
                    }
                    
                    ActionButton(title: "Mapa", icon: "map.fill", color: .orange) {
                        openInMaps()
                    }
                }
                .padding(.horizontal)
                
                // Details Card
                VStack(alignment: .leading, spacing: 20) {
                    DetailRow(icon: "person.text.rectangle.fill", title: "Contato", value: contact.name)
                    DetailRow(icon: "envelope.fill", title: "E-mail", value: contact.email)
                    DetailRow(icon: "phone.fill", title: "Telefone", value: contact.phone)
                    DetailRow(icon: "calendar", title: "Data de Nascimento", value: contact.birthDateString)
                    
                    Divider()
                    
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "map.fill")
                                .foregroundColor(.indigo)
                            Text("Endereço Residencial")
                                .font(.headline)
                                .foregroundColor(.primary)
                        }
                        .padding(.bottom, 4)
                        
                        AddressFieldRow(title: "CEP", value: contact.cep)
                        AddressFieldRow(title: "Logradouro (Rua)", value: "\(contact.street), \(contact.number)")
                        AddressFieldRow(title: "Bairro", value: contact.neighborhood)
                        AddressFieldRow(title: "Cidade", value: contact.city)
                        AddressFieldRow(title: "Estado", value: contact.state)
                    }
                }
                .padding(20)
                .background(Color(.secondarySystemGroupedBackground))
                .cornerRadius(16)
                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
                .padding(.horizontal)
                
                // Delete Button
                if isDeleting {
                    ProgressView()
                } else {
                    Button(action: {
                        showDeleteAlert = true
                    }) {
                        Label("Excluir Contato", systemImage: "trash.fill")
                            .bold()
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(12)
                            .shadow(color: .red.opacity(0.2), radius: 6, x: 0, y: 3)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 24)
                }
            }
        }
        .background(Color(.systemGroupedBackground))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Editar") {
                    showEditSheet = true
                }
                .bold()
                .foregroundColor(.indigo)
            }
        }
        .sheet(isPresented: $showEditSheet) {
            NavigationStack {
                ContactFormView(listViewModel: listViewModel, contact: contact)
            }
        }
        .alert("Excluir Contato", isPresented: $showDeleteAlert) {
            Button("Cancelar", role: .cancel) { }
            Button("Excluir", role: .destructive) {
                deleteContact()
            }
        } message: {
            Text("Tem certeza que deseja excluir o contato '\(contact.name)'?")
        }
    }
    
    private func getInitials(from name: String) -> String {
        let words = name.split(separator: " ")
        if words.isEmpty { return "" }
        if words.count == 1 {
            return String(words[0].prefix(1)).uppercased()
        }
        let first = words[0].prefix(1)
        let last = words[words.count - 1].prefix(1)
        return "\(first)\(last)".uppercased()
    }
    
    private func callContact() {
        let cleanPhone = contact.phone.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        if let url = URL(string: "tel://\(cleanPhone)") {
            UIApplication.shared.open(url)
        }
    }
    
    private func emailContact() {
        if let url = URL(string: "mailto:\(contact.email)") {
            UIApplication.shared.open(url)
        }
    }
    
    private func openInMaps() {
        let addressString = "\(contact.street), \(contact.number) - \(contact.neighborhood), \(contact.city) - \(contact.state), \(contact.cep)"
        if let encodedAddress = addressString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
           let url = URL(string: "maps://?q=\(encodedAddress)") {
            UIApplication.shared.open(url)
        }
    }
    
    private func deleteContact() {
        isDeleting = true
        Task {
            await listViewModel.deleteContact(contact)
            isDeleting = false
            dismiss()
        }
    }
}

// Subview components
struct ActionButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundColor(color)
                    .frame(width: 50, height: 50)
                    .background(color.opacity(0.1))
                    .clipShape(Circle())
                
                Text(title)
                    .font(.caption)
                    .bold()
                    .foregroundColor(.primary)
            }
            .frame(width: 80)
        }
    }
}

struct DetailRow: View {
    let icon: String
    let title: String
    let value: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .foregroundColor(.indigo)
                .frame(width: 24, height: 24)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption2)
                    .foregroundColor(.secondary)
                Text(value)
                    .font(.body)
                    .bold()
            }
            Spacer()
        }
    }
}

struct AddressFieldRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack(alignment: .top) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
                .frame(width: 120, alignment: .leading)
            
            Text(value)
                .font(.subheadline)
                .bold()
                .foregroundColor(.primary)
            
            Spacer()
        }
    }
}

struct ContactDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ContactDetailView(
                listViewModel: ContactListViewModel(),
                contact: Contact(
                    name: "Ana Silva",
                    email: "ana.silva@email.com",
                    phone: "(11) 98888-1111",
                    birthDate: Date(),
                    cep: "01001-000",
                    neighborhood: "Sé",
                    street: "Praça da Sé",
                    number: "100",
                    state: "SP",
                    city: "São Paulo"
                )
            )
        }
    }
}
