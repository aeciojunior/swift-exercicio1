import SwiftUI

struct ContactListView: View {
    @StateObject var viewModel = ContactListViewModel()
    @State private var showFormSheet = false
    @State private var showSettingsSheet = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground)
                    .ignoresSafeArea()
                
                if viewModel.isLoading && viewModel.contacts.isEmpty {
                    VStack(spacing: 16) {
                        ProgressView()
                            .scaleEffect(1.5)
                        Text("Buscando contatos...")
                            .foregroundColor(.secondary)
                            .font(.subheadline)
                    }
                } else if viewModel.contacts.isEmpty {
                    // Empty State
                    EmptyStateView(
                        title: "Nenhum Contato Cadastrado",
                        subtitle: "Seus contatos do banco \(viewModel.currentRepository.name) aparecerão aqui. Toque no botão + para adicionar um novo.",
                        icon: "person.3.fill",
                        buttonTitle: "Adicionar Primeiro Contato"
                    ) {
                        showFormSheet = true
                    }
                } else if viewModel.filteredContacts.isEmpty {
                    // Search Empty State
                    EmptyStateView(
                        title: "Nenhum Resultado",
                        subtitle: "Não encontramos contatos correspondentes a \"\(viewModel.searchQuery)\". Tente buscar por outro termo.",
                        icon: "magnifyingglass",
                        buttonTitle: nil,
                        action: nil
                    )
                } else {
                    // Contact list
                    List {
                        Section {
                            ForEach(viewModel.filteredContacts) { contact in
                                NavigationLink(destination: ContactDetailView(listViewModel: viewModel, contact: contact)) {
                                    ContactRowView(contact: contact)
                                }
                            }
                            .onDelete(perform: deleteContactAtIndex)
                        } header: {
                            Text("Lista de Contatos (\(viewModel.filteredContacts.count))")
                                .font(.caption)
                                .bold()
                        }
                    }
                }
            }
            .navigationTitle("Meus Contatos")
            .searchable(text: $viewModel.searchQuery, prompt: "Buscar por nome, e-mail ou cidade...")
            .refreshable {
                await viewModel.fetchContacts()
            }
            .toolbar {
                // Left Toolbar: Database indicator capsule
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        showSettingsSheet = true
                    }) {
                        HStack(spacing: 4) {
                            Circle()
                                .fill(badgeColor(for: viewModel.activeRepositoryType))
                                .frame(width: 8, height: 8)
                            Text(viewModel.activeRepositoryType.rawValue)
                                .font(.caption2)
                                .bold()
                                .foregroundColor(.primary)
                            Image(systemName: "chevron.down")
                                .font(.system(size: 8, weight: .bold))
                                .foregroundColor(.secondary)
                        }
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                        .background(Color(.secondarySystemGroupedBackground))
                        .cornerRadius(12)
                        .shadow(color: Color.black.opacity(0.05), radius: 2)
                    }
                }
                
                // Right Toolbar: Settings and Add Contact
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 12) {
                        Button(action: {
                            showSettingsSheet = true
                        }) {
                            Image(systemName: "gearshape.fill")
                                .foregroundColor(.indigo)
                        }
                        
                        Button(action: {
                            showFormSheet = true
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title3)
                                .foregroundColor(.indigo)
                        }
                    }
                }
            }
            .sheet(isPresented: $showFormSheet) {
                NavigationStack {
                    ContactFormView(listViewModel: viewModel)
                }
            }
            .sheet(isPresented: $showSettingsSheet) {
                SettingsView(viewModel: viewModel)
            }
            .overlay {
                if viewModel.isLoading && !viewModel.contacts.isEmpty {
                    // Small loading card for refresh
                    VStack {
                        ProgressView("Carregando...")
                            .padding()
                            .background(Color(.secondarySystemBackground))
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom, 24)
                }
            }
        }
    }
    
    private func deleteContactAtIndex(at offsets: IndexSet) {
        for index in offsets {
            let contact = viewModel.filteredContacts[index]
            Task {
                await viewModel.deleteContact(contact)
            }
        }
    }
    
    private func badgeColor(for type: ContactListViewModel.RepositoryType) -> Color {
        switch type {
        case .inMemory: return .orange
        case .coreData: return .blue
        case .api: return .purple
        }
    }
}

// Subview components
struct ContactRowView: View {
    let contact: Contact
    
    var body: some View {
        HStack(spacing: 16) {
            Circle()
                .fill(LinearGradient(gradient: Gradient(colors: [.indigo, .purple]), startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 48, height: 48)
                .overlay(
                    Text(getInitials(from: contact.name))
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                )
            
            VStack(alignment: .leading, spacing: 4) {
                Text(contact.name)
                    .font(.body)
                    .bold()
                    .foregroundColor(.primary)
                
                HStack(spacing: 6) {
                    Image(systemName: "phone.fill")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                    Text(contact.phone)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                HStack(spacing: 6) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                    Text("\(contact.city) - \(contact.state)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(.vertical, 4)
    }
    
    private func getInitials(from name: String) -> String {
        let words = name.split(separator: " ")
        if words.isEmpty { return "" }
        if words.count == 1 {
            return String(words[0].prefix(1)).uppercased()
        }
        let first = words[0].prefix(1)
        let last = words[words.count - 1].prefix(1)
        return "\(first)\(last)".uppercased()
    }
}

struct EmptyStateView: View {
    let title: String
    let subtitle: String
    let icon: String
    let buttonTitle: String?
    let action: (() -> Void)?
    
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 64))
                .foregroundColor(.indigo.opacity(0.5))
                .padding(.bottom, 8)
            
            Text(title)
                .font(.title3)
                .bold()
                .foregroundColor(.primary)
            
            Text(subtitle)
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            
            if let buttonTitle = buttonTitle, let action = action {
                Button(action: action) {
                    Text(buttonTitle)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(Color.indigo)
                        .cornerRadius(10)
                        .shadow(color: .indigo.opacity(0.3), radius: 6, x: 0, y: 3)
                }
                .padding(.top, 8)
            }
        }
        .padding()
    }
}

struct ContactListView_Previews: PreviewProvider {
    static var previews: some View {
        ContactListView()
    }
}
