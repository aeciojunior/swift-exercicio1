import SwiftUI

struct SettingsView: View {
    @ObservedObject var viewModel: ContactListViewModel
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Mecanismo de Armazenamento")
                    .foregroundColor(.indigo)
                    .font(.caption)
                    .bold()
                ) {
                    Picker("Banco ativo", selection: $viewModel.activeRepositoryType) {
                        ForEach(ContactListViewModel.RepositoryType.allCases) { repoType in
                            Text(repoType.rawValue).tag(repoType)
                        }
                    }
                    .pickerStyle(.inline)
                }
                
                Section(header: Text("Estatísticas e Status")
                    .foregroundColor(.indigo)
                    .font(.caption)
                    .bold()
                ) {
                    HStack {
                        Text("Contatos salvos:")
                        Spacer()
                        Text("\(viewModel.contacts.count)")
                            .foregroundColor(.secondary)
                            .bold()
                    }
                    HStack {
                        Text("Tipo de Armazenamento:")
                        Spacer()
                        Text(viewModel.currentRepository.name)
                            .bold()
                            .foregroundColor(.indigo)
                    }
                }
                
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Vetor (Memória)", systemImage: "bolt.fill")
                            .font(.subheadline)
                            .foregroundColor(.orange)
                        Text("Armazena em um vetor temporário na memória RAM do app. Os dados serão perdidos se o aplicativo for fechado.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Divider().padding(.vertical, 4)
                        
                        Label("Core Data (SQLite)", systemImage: "cylinder.split.1x2.fill")
                            .font(.subheadline)
                            .foregroundColor(.blue)
                        Text("Persistência local robusta utilizando banco de dados SQLite nativo. Os dados são mantidos mesmo após reiniciar o dispositivo.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Divider().padding(.vertical, 4)
                        
                        Label("API Remota (Simulada)", systemImage: "cloud.fill")
                            .font(.subheadline)
                            .foregroundColor(.purple)
                        Text("Simula chamadas a uma API de nuvem externa armazenada no UserDefaults local com delay de rede de 0.8s para demonstrar loaders.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("Armazenamento")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Fechar") {
                        dismiss()
                    }
                    .bold()
                    .foregroundColor(.indigo)
                }
            }
        }
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView(viewModel: ContactListViewModel())
    }
}
