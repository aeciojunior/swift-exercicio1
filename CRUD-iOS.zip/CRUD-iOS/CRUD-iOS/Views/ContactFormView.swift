import SwiftUI

struct ContactFormView: View {
    @ObservedObject var listViewModel: ContactListViewModel
    @StateObject var viewModel: ContactFormViewModel
    
    @Environment(\.dismiss) var dismiss
    @State private var isSaving: Bool = false
    @State private var saveErrorMessage: String? = nil
    
    public init(listViewModel: ContactListViewModel, contact: Contact? = nil) {
        self.listViewModel = listViewModel
        self._viewModel = StateObject(wrappedValue: ContactFormViewModel(contact: contact))
    }
    
    var body: some View {
        Form {
            Section(header: Label("Informações Pessoais", systemImage: "person.fill").foregroundColor(.indigo).font(.caption).bold()) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Nome")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    TextField("Ex: João da Silva", text: $viewModel.name)
                        .textInputAutocapitalization(.words)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("E-mail")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    TextField("Ex: joao@email.com", text: $viewModel.email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Telefone")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    TextField("Ex: (11) 99999-9999", text: $viewModel.phone)
                        .keyboardType(.phonePad)
                }
                
                DatePicker("Nascimento", selection: $viewModel.birthDate, displayedComponents: .date)
                    .environment(\.locale, Locale(identifier: "pt_BR"))
            }
            
            Section(header: Label("Endereço", systemImage: "map.fill").foregroundColor(.indigo).font(.caption).bold()) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("CEP")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    HStack {
                        TextField("00000-000", text: $viewModel.cep)
                            .keyboardType(.numberPad)
                            
                        if viewModel.isCEPLoading {
                            ProgressView()
                                .padding(.leading, 8)
                        } else if !viewModel.cep.isEmpty {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                                .opacity(viewModel.cep.components(separatedBy: CharacterSet.decimalDigits.inverted).joined().count == 8 ? 1 : 0)
                        }
                    }
                    if let cepErr = viewModel.cepError {
                        Text(cepErr)
                            .font(.caption2)
                            .foregroundColor(.red)
                    }
                }
                
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Logradouro (Rua)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        TextField("Rua, Avenida, etc.", text: $viewModel.street)
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Número")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        TextField("Nº", text: $viewModel.number)
                            .keyboardType(.asciiCapableNumberPad)
                    }
                    .frame(width: 80)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("Bairro")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    TextField("Ex: Centro", text: $viewModel.neighborhood)
                }
                
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Cidade")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        TextField("Ex: São Paulo", text: $viewModel.city)
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Estado (UF)")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        TextField("Ex: SP", text: $viewModel.state)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                    }
                    .frame(width: 80)
                }
            }
            
            if let err = saveErrorMessage {
                Section {
                    Text(err)
                        .foregroundColor(.red)
                        .font(.subheadline)
                }
            }
        }
        .navigationTitle(viewModel.editingContact == nil ? "Adicionar Contato" : "Editar Contato")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button("Cancelar") {
                    dismiss()
                }
                .foregroundColor(.red)
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                if isSaving {
                    ProgressView()
                } else {
                    Button("Salvar") {
                        saveContact()
                    }
                    .bold()
                    .foregroundColor(.indigo)
                }
            }
        }
        .alert("Aviso", isPresented: $viewModel.showValidationErrorAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(viewModel.validationErrorMessage)
        }
    }
    
    private func saveContact() {
        guard viewModel.validateForm() else { return }
        
        isSaving = true
        saveErrorMessage = nil
        
        Task {
            do {
                try await viewModel.save(to: listViewModel.currentRepository)
                await listViewModel.fetchContacts()
                isSaving = false
                dismiss()
            } catch {
                isSaving = false
                saveErrorMessage = "Erro ao salvar contato: \(error.localizedDescription)"
            }
        }
    }
}

struct ContactFormView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ContactFormView(listViewModel: ContactListViewModel())
        }
    }
}
