import Foundation

public struct Contact: Identifiable, Codable, Hashable {
    public var id: UUID
    public var name: String
    public var email: String
    public var phone: String
    public var birthDate: Date
    public var cep: String
    public var neighborhood: String   // Bairro
    public var street: String         // Logradouro
    public var number: String         // Número
    public var state: String          // Estado
    public var city: String           // Cidade
    
    public init(
        id: UUID = UUID(),
        name: String,
        email: String,
        phone: String,
        birthDate: Date,
        cep: String,
        neighborhood: String,
        street: String,
        number: String,
        state: String,
        city: String
    ) {
        self.id = id
        self.name = name
        self.email = email
        self.phone = phone
        self.birthDate = birthDate
        self.cep = cep
        self.neighborhood = neighborhood
        self.street = street
        self.number = number
        self.state = state
        self.city = city
    }
    
    // Helper to format date
    public var birthDateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter.string(from: birthDate)
    }
}
