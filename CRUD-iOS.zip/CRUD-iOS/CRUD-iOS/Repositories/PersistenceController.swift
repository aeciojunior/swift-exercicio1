import Foundation
import CoreData

@objc(ContactEntity)
public class ContactEntity: NSManagedObject {
    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var email: String?
    @NSManaged public var phone: String?
    @NSManaged public var birthDate: Date?
    @NSManaged public var cep: String?
    @NSManaged public var neighborhood: String?
    @NSManaged public var street: String?
    @NSManaged public var number: String?
    @NSManaged public var state: String?
    @NSManaged public var city: String?
}

extension NSManagedObjectModel {
    static func makeProgrammaticModel() -> NSManagedObjectModel {
        let model = NSManagedObjectModel()
        
        let entity = NSEntityDescription()
        entity.name = "ContactEntity"
        entity.managedObjectClassName = NSStringFromClass(ContactEntity.self)
        
        var properties = [NSPropertyDescription]()
        
        func addAttribute(_ name: String, type: NSAttributeType, optional: Bool = true) {
            let attr = NSAttributeDescription()
            attr.name = name
            attr.attributeType = type
            attr.isOptional = optional
            properties.append(attr)
        }
        
        addAttribute("id", type: .UUIDAttributeType, optional: false)
        addAttribute("name", type: .stringAttributeType, optional: false)
        addAttribute("email", type: .stringAttributeType, optional: false)
        addAttribute("phone", type: .stringAttributeType, optional: false)
        addAttribute("birthDate", type: .dateAttributeType, optional: false)
        addAttribute("cep", type: .stringAttributeType, optional: false)
        addAttribute("neighborhood", type: .stringAttributeType, optional: false)
        addAttribute("street", type: .stringAttributeType, optional: false)
        addAttribute("number", type: .stringAttributeType, optional: false)
        addAttribute("state", type: .stringAttributeType, optional: false)
        addAttribute("city", type: .stringAttributeType, optional: false)
        
        entity.properties = properties
        model.entities = [entity]
        
        return model
    }
}

public class PersistenceController {
    public static let shared = PersistenceController()
    
    // For SwiftUI previews
    public static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let viewContext = result.container.viewContext
        for i in 0..<5 {
            let newContact = ContactEntity(context: viewContext)
            newContact.id = UUID()
            newContact.name = "Contato Exemplo \(i + 1)"
            newContact.email = "exemplo\(i + 1)@email.com"
            newContact.phone = "(11) 99999-999\(i)"
            newContact.birthDate = Calendar.current.date(byAdding: .year, value: -20 - i, to: Date()) ?? Date()
            newContact.cep = "01001-000"
            newContact.neighborhood = "Sé"
            newContact.street = "Praça da Sé"
            newContact.number = "\(100 * (i + 1))"
            newContact.state = "SP"
            newContact.city = "São Paulo"
        }
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
        return result
    }()
    
    public let container: NSPersistentContainer
    
    public init(inMemory: Bool = false) {
        let model = NSManagedObjectModel.makeProgrammaticModel()
        container = NSPersistentContainer(name: "ContactModel", managedObjectModel: model)
        
        if inMemory {
            if let desc = container.persistentStoreDescriptions.first {
                desc.url = URL(fileURLWithPath: "/dev/null")
            }
        }
        
        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }
}
