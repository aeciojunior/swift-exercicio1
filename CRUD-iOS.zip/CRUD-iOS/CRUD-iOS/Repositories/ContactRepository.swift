import Foundation
import CoreData

public protocol ContactRepository {
    var name: String { get }
    func fetchContacts() async throws -> [Contact]
    func save(contact: Contact) async throws
    func update(contact: Contact) async throws
    func delete(contact: Contact) async throws
}

// MARK: - 1. In Memory / Vetor Repository (Em Memória)
public class InMemoryContactRepository: ContactRepository {
    public let name = "Vetor (Memória)"
    private var contacts: [Contact] = []
    
    public init() {
        // Pre-populate with mockup data for testing
        self.contacts = [
            Contact(name: "Ana Silva", email: "ana.silva@email.com", phone: "(11) 98888-1111", birthDate: Date(timeIntervalSince1970: 631152000), cep: "01001-000", neighborhood: "Sé", street: "Praça da Sé", number: "100", state: "SP", city: "São Paulo"),
            Contact(name: "Bruno Souza", email: "bruno.souza@email.com", phone: "(21) 97777-2222", birthDate: Date(timeIntervalSince1970: 788918400), cep: "20020-010", neighborhood: "Centro", street: "Avenida Presidente Wilson", number: "210", state: "RJ", city: "Rio de Janeiro")
        ]
    }
    
    public func fetchContacts() async throws -> [Contact] {
        return contacts
    }
    
    public func save(contact: Contact) async throws {
        if !contacts.contains(where: { $0.id == contact.id }) {
            contacts.append(contact)
        }
    }
    
    public func update(contact: Contact) async throws {
        if let index = contacts.firstIndex(where: { $0.id == contact.id }) {
            contacts[index] = contact
        }
    }
    
    public func delete(contact: Contact) async throws {
        contacts.removeAll(where: { $0.id == contact.id })
    }
}

// MARK: - 2. Core Data Repository (SQLite)
public class CoreDataContactRepository: ContactRepository {
    public let name = "Core Data (SQLite)"
    private let context: NSManagedObjectContext
    
    public init(context: NSManagedObjectContext = PersistenceController.shared.container.viewContext) {
        self.context = context
    }
    
    public func fetchContacts() async throws -> [Contact] {
        return try await context.perform {
            let request = NSFetchRequest<ContactEntity>(entityName: "ContactEntity")
            // Sort alphabetically by name
            request.sortDescriptors = [NSSortDescriptor(keyPath: \ContactEntity.name, ascending: true)]
            
            let entities = try self.context.fetch(request)
            return entities.map { entity in
                Contact(
                    id: entity.id ?? UUID(),
                    name: entity.name ?? "",
                    email: entity.email ?? "",
                    phone: entity.phone ?? "",
                    birthDate: entity.birthDate ?? Date(),
                    cep: entity.cep ?? "",
                    neighborhood: entity.neighborhood ?? "",
                    street: entity.street ?? "",
                    number: entity.number ?? "",
                    state: entity.state ?? "",
                    city: entity.city ?? ""
                )
            }
        }
    }
    
    public func save(contact: Contact) async throws {
        try await context.perform {
            let entity = ContactEntity(context: self.context)
            entity.id = contact.id
            entity.name = contact.name
            entity.email = contact.email
            entity.phone = contact.phone
            entity.birthDate = contact.birthDate
            entity.cep = contact.cep
            entity.neighborhood = contact.neighborhood
            entity.street = contact.street
            entity.number = contact.number
            entity.state = contact.state
            entity.city = contact.city
            
            try self.context.save()
        }
    }
    
    public func update(contact: Contact) async throws {
        try await context.perform {
            let request = NSFetchRequest<ContactEntity>(entityName: "ContactEntity")
            request.predicate = NSPredicate(format: "id == %@", contact.id as CVarArg)
            
            if let entity = try self.context.fetch(request).first {
                entity.name = contact.name
                entity.email = contact.email
                entity.phone = contact.phone
                entity.birthDate = contact.birthDate
                entity.cep = contact.cep
                entity.neighborhood = contact.neighborhood
                entity.street = contact.street
                entity.number = contact.number
                entity.state = contact.state
                entity.city = contact.city
                
                try self.context.save()
            }
        }
    }
    
    public func delete(contact: Contact) async throws {
        try await context.perform {
            let request = NSFetchRequest<ContactEntity>(entityName: "ContactEntity")
            request.predicate = NSPredicate(format: "id == %@", contact.id as CVarArg)
            
            if let entity = try self.context.fetch(request).first {
                self.context.delete(entity)
                try self.context.save()
            }
        }
    }
}

// MARK: - 3. API Repository (Simulated External Cloud API)
public class APIContactRepository: ContactRepository {
    public let name = "API Remota (Simulada)"
    private let userDefaultsKey = "simulated_api_contacts"
    
    // We simulate API network delay (0.8s) for all operations to show loaders
    private func simulateNetworkDelay() async throws {
        try await Task.sleep(nanoseconds: 800_000_000) // 0.8 seconds
    }
    
    private func getContactsFromStorage() -> [Contact] {
        guard let data = UserDefaults.standard.data(forKey: userDefaultsKey),
              let list = try? JSONDecoder().decode([Contact].self, from: data) else {
            // Seed with API initial data
            let initial = [
                Contact(name: "Carlos Andrade (API)", email: "carlos@api.com", phone: "(31) 98765-4321", birthDate: Date(timeIntervalSince1970: 725846400), cep: "30140-010", neighborhood: "Savassi", street: "Avenida Cristóvão Colombo", number: "500", state: "MG", city: "Belo Horizonte")
            ]
            saveContactsToStorage(initial)
            return initial
        }
        return list
    }
    
    private func saveContactsToStorage(_ list: [Contact]) {
        if let encoded = try? JSONEncoder().encode(list) {
            UserDefaults.standard.set(encoded, forKey: userDefaultsKey)
        }
    }
    
    public func fetchContacts() async throws -> [Contact] {
        try await simulateNetworkDelay()
        return getContactsFromStorage()
    }
    
    public func save(contact: Contact) async throws {
        try await simulateNetworkDelay()
        var list = getContactsFromStorage()
        if !list.contains(where: { $0.id == contact.id }) {
            list.append(contact)
            saveContactsToStorage(list)
        }
    }
    
    public func update(contact: Contact) async throws {
        try await simulateNetworkDelay()
        var list = getContactsFromStorage()
        if let index = list.firstIndex(where: { $0.id == contact.id }) {
            list[index] = contact
            saveContactsToStorage(list)
        }
    }
    
    public func delete(contact: Contact) async throws {
        try await simulateNetworkDelay()
        var list = getContactsFromStorage()
        list.removeAll(where: { $0.id == contact.id })
        saveContactsToStorage(list)
    }
}
